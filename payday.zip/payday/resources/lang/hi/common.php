<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Common Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used for commom use messages
    | that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'something_went_wrong' => 'कुछ गलत हुआ है, बाद में पुन: प्रयास करें!',
    'user_create_success' => 'उपयोगकर्ता सफलतापूर्वक बनाया गया',
    'user_upd_success' => 'उपयोगकर्ता सफलतापूर्वक अपडेट किया गया',
    'user_del_success' => 'उपयोगकर्ता सफलतापूर्वक हटा दिया गया',
    'user_get_success' => 'उपयोगकर्ता को सफलतापूर्वक लाया गया',
    'token_create_success' => 'टोकन सफलतापूर्वक बनाया गया',
    'invalid_mob_otp' => 'अमान्य मोबाइल या ओटीपी',
    'invalid_mob_pass' => 'अमान्य मोबाइल या पासवर्ड',
    'logout' => 'लॉगआउट सफलतापूर्वक',
    'already_logout' => 'उपयोगकर्ता पहले से ही लॉगआउट',
    'otp_send_success' => 'ओटीपी सफलतापूर्वक भेजा गया',
    'user_not_found' => 'उपयोगकर्ता नहीं मिला',
    'token_ref_success' => 'टोकन सफलतापूर्वक ताज़ा किया गया',
    'login_again' => 'कृपया फिर लॉगिन करें',
    'password_upd_success' => 'पासवर्ड सफलतापूर्वक अपडेट हो गया',
    'password_not_match' => 'Password not matched',
    'login_first' => 'कृपया पहले Login करें',
    'image_upload_success'=>'Image सफलतापूर्वक अपलोड की गई',
    'User_Info_success'=>'उपयोगकर्ता की जानकारी सफलतापूर्वक अपडेट की गई',
    'get_lang_success'=>'सभी भाषाएं सफलतापूर्वक प्राप्त की',
    'get_all_states_success'=>'सभी राज्यों को सफलतापूर्वक प्राप्त करें',
    'get_all_states_success'=>'सभी कंपनियों को सफलतापूर्वक प्राप्त करें',
    'create_company_success'=>'कंपनी सफलतापूर्वक बनाई गई',
    'get_sal_mode_success'=>'Salary mode fetched successfully',


    /*
    |--------------------------------------------------------------------------
    | Custom Validation Attributes
    |--------------------------------------------------------------------------
    |
    | The following language lines are used to swap our attribute placeholder
    | with something more reader friendly such as "E-Mail Address" instead
    | of "email". This simply helps us make our message more expressive.
    |
    */

    'attributes' => [],

];
