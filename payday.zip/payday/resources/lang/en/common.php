<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Common Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used for commom use messages
    | that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'something_went_wrong' => 'Something went wrong, Try again later!',
    'user_create_success' => 'User created successfully',
    'user_upd_success' => 'User updated successfully',
    'user_del_success' => 'User deleted successfully',
    'user_get_success' => 'User fetched successfully',
    'token_create_success' => 'Token created successfully',
    'invalid_mob_otp' => 'Invalid Mobile or OTP',
    'invalid_mob_pass' => 'Invalid Mobile or Password',
    'logout' => 'Logout successfully',
    'already_logout' => 'User already Logout',
    'otp_send_success' => 'OTP send successfully',
    'user_not_found' => 'User not found',
    'token_ref_success' => 'Token refreshed successfully',
    'login_again' => 'Please login again',
    'password_upd_success' => 'Password updated successfully',
    'password_not_match' => 'Password not matched',
    'login_first' => 'Please login first',
    'image_upload_success'=>'Image uploaded successfully',
    'User_Info_success'=>'User Info Updated successfully',
    'get_lang_success'=>'Get All Languages successfully',
    'get_all_states_success'=>'Get All States successfully',
    'get_all_states_success'=>'Get All Companies successfully',
    'create_company_success'=>'Company created successfully',
    'get_sal_mode_success'=>'Salary mode fetched successfully',

    /*
    |--------------------------------------------------------------------------
    | Custom Validation Attributes
    |--------------------------------------------------------------------------
    |
    | The following language lines are used to swap our attribute placeholder
    | with something more reader friendly such as "E-Mail Address" instead
    | of "email". This simply helps us make our message more expressive.
    |
    */

    'attributes' => [],

];
