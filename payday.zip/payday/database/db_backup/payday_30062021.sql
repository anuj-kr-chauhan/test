-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Generation Time: Jun 30, 2021 at 01:04 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `payday`
--

-- --------------------------------------------------------

--
-- Table structure for table `pro_activity_log`
--

DROP TABLE IF EXISTS `pro_activity_log`;
CREATE TABLE IF NOT EXISTS `pro_activity_log` (
  `activity_log_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `activity_id` smallint(5) UNSIGNED NOT NULL,
  `activity_desc` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_address` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `route_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `app_id` int(10) UNSIGNED DEFAULT NULL,
  `email` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `browser_info` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `device_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(10) UNSIGNED NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`activity_log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pro_api_log`
--

DROP TABLE IF EXISTS `pro_api_log`;
CREATE TABLE IF NOT EXISTS `pro_api_log` (
  `api_log_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(10) UNSIGNED NOT NULL,
  `doc_id` smallint(5) UNSIGNED NOT NULL,
  `doc_id_no` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `api_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `req_txt` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `res_txt` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ipaddr` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(10) UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  `api_url` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_verified` tinyint(3) UNSIGNED NOT NULL COMMENT '1=>verfied,0=> un verified',
  `created_by` int(10) UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  PRIMARY KEY (`api_log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pro_app`
--

DROP TABLE IF EXISTS `pro_app`;
CREATE TABLE IF NOT EXISTS `pro_app` (
  `app_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(10) UNSIGNED NOT NULL,
  `is_active` tinyint(3) UNSIGNED NOT NULL DEFAULT 0 COMMENT '1=> Active',
  `app_status_id` smallint(5) UNSIGNED NOT NULL,
  `created_by` int(10) UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(10) UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  PRIMARY KEY (`app_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pro_app_info`
--

DROP TABLE IF EXISTS `pro_app_info`;
CREATE TABLE IF NOT EXISTS `pro_app_info` (
  `app_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(10) UNSIGNED NOT NULL,
  `created_by` int(10) UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(10) UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  PRIMARY KEY (`app_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pro_app_status`
--

DROP TABLE IF EXISTS `pro_app_status`;
CREATE TABLE IF NOT EXISTS `pro_app_status` (
  `app_status_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `app_id` int(10) UNSIGNED NOT NULL,
  `status_id` smallint(5) UNSIGNED NOT NULL,
  `cmt_txt` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` int(10) UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`app_status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pro_company`
--

DROP TABLE IF EXISTS `pro_company`;
CREATE TABLE IF NOT EXISTS `pro_company` (
  `comp_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(10) UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(10) UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  PRIMARY KEY (`comp_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pro_company`
--

INSERT INTO `pro_company` (`comp_id`, `name`, `created_by`, `created_at`, `updated_at`, `updated_by`) VALUES
(1, 'Keen', NULL, '2021-06-25 06:44:10', '2021-06-25 06:44:10', NULL),
(2, 'Keen2', NULL, '2021-06-26 05:22:39', '2021-06-26 05:22:39', NULL),
(3, 'ABC', NULL, '2021-06-26 06:03:00', '2021-06-26 06:03:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pro_failed_jobs`
--

DROP TABLE IF EXISTS `pro_failed_jobs`;
CREATE TABLE IF NOT EXISTS `pro_failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `pro_failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pro_migrations`
--

DROP TABLE IF EXISTS `pro_migrations`;
CREATE TABLE IF NOT EXISTS `pro_migrations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pro_migrations`
--

INSERT INTO `pro_migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2016_06_01_000001_create_oauth_auth_codes_table', 1),
(4, '2016_06_01_000002_create_oauth_access_tokens_table', 1),
(5, '2016_06_01_000003_create_oauth_refresh_tokens_table', 1),
(6, '2016_06_01_000004_create_oauth_clients_table', 1),
(7, '2016_06_01_000005_create_oauth_personal_access_clients_table', 1),
(8, '2019_08_19_000000_create_failed_jobs_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `pro_mst_activity`
--

DROP TABLE IF EXISTS `pro_mst_activity`;
CREATE TABLE IF NOT EXISTS `pro_mst_activity` (
  `id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT,
  `route_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `activity_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activity_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(3) UNSIGNED NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pro_mst_activity`
--

INSERT INTO `pro_mst_activity` (`id`, `route_name`, `activity_code`, `activity_name`, `is_active`, `created_by`, `created_at`, `updated_at`) VALUES
(1, '', 'frontend_reg', 'FrontendRegistration', 1, 1, NULL, NULL),
(2, '', 'email_verified', 'Email Verified', 1, NULL, NULL, NULL),
(3, '', 'mobile_otp_verified', 'mobile_otp_verified', 1, NULL, NULL, NULL),
(4, '', 'login', 'Login', 1, NULL, NULL, NULL),
(5, '', 'first_time_password_change', 'first_time_password_change', 1, NULL, NULL, NULL),
(6, '', 'supplier_form_sbumit', 'supplier_form_sbumit', 1, NULL, NULL, NULL),
(7, '', 'change_pwd', 'change_pwd', 1, NULL, NULL, NULL),
(8, '', 'forget_pwd', 'forget_pwd', 1, NULL, NULL, NULL),
(9, '', 'invpice_upload', 'invpice_upload', 1, NULL, NULL, NULL),
(10, '', 'tally_posting', 'tally_posting', 1, NULL, NULL, NULL),
(11, '', 'offer_creation', 'offer_creation', 1, NULL, NULL, NULL),
(12, '', 'user_limit_enhancement', 'user_limit_enhancement', 1, NULL, NULL, NULL),
(13, '', 'user_product_limit_enhancement', 'user_product_limit_enhancement', 1, NULL, NULL, NULL),
(14, '', 'Invoice_send_to_disburesement', 'Invoice_send_to_disburesement', 1, NULL, NULL, NULL),
(15, '', 'Invoice_Upload_manul_single', 'Invoice_Upload_manul_single', 1, NULL, NULL, NULL),
(16, ' ', 'application_renewal', 'Application Renewal', 1, 1, '2020-04-29 18:30:00', NULL),
(17, ' ', 'app_status_changed', 'Application Status Changed', 1, 1, '2020-04-30 00:00:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pro_mst_state`
--

DROP TABLE IF EXISTS `pro_mst_state`;
CREATE TABLE IF NOT EXISTS `pro_mst_state` (
  `state_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `created_by` int(10) UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(10) UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  PRIMARY KEY (`state_id`)
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pro_mst_state`
--

INSERT INTO `pro_mst_state` (`state_id`, `name`, `created_by`, `created_at`, `updated_at`, `updated_by`) VALUES
(1, 'ANDAMAN AND NICOBAR ISLANDS', NULL, NULL, NULL, NULL),
(2, 'ANDHRA PRADESH', NULL, NULL, NULL, NULL),
(3, 'ARUNACHAL PRADESH', NULL, NULL, NULL, NULL),
(4, 'ASSAM', NULL, NULL, NULL, NULL),
(5, 'BIHAR', NULL, NULL, NULL, NULL),
(6, 'CHATTISGARH', NULL, NULL, NULL, NULL),
(7, 'CHANDIGARH', NULL, NULL, NULL, NULL),
(8, 'DAMAN AND DIU', NULL, NULL, NULL, NULL),
(9, 'DELHI', NULL, NULL, NULL, NULL),
(10, 'DADRA AND NAGAR HAVELI', NULL, NULL, NULL, NULL),
(11, 'GOA', NULL, NULL, NULL, NULL),
(12, 'GUJARAT', NULL, NULL, NULL, NULL),
(13, 'HIMACHAL PRADESH', NULL, NULL, NULL, NULL),
(14, 'HARYANA', NULL, NULL, NULL, NULL),
(15, 'JAMMU AND KASHMIR', NULL, NULL, NULL, NULL),
(16, 'JHARKHAND', NULL, NULL, NULL, NULL),
(17, 'KERALA', NULL, NULL, NULL, NULL),
(18, 'KARNATAKA', NULL, NULL, NULL, NULL),
(19, 'LAKSHADWEEP', NULL, NULL, NULL, NULL),
(20, 'MEGHALAYA', NULL, NULL, NULL, NULL),
(21, 'MAHARASHTRA', NULL, NULL, NULL, NULL),
(22, 'MANIPUR', NULL, NULL, NULL, NULL),
(23, 'MADHYA PRADESH', NULL, NULL, NULL, NULL),
(24, 'MIZORAM', NULL, NULL, NULL, NULL),
(25, 'NAGALAND', NULL, NULL, NULL, NULL),
(26, 'ORISSA', NULL, NULL, NULL, NULL),
(27, 'PUNJAB', NULL, NULL, NULL, NULL),
(28, 'PONDICHERRY', NULL, NULL, NULL, NULL),
(29, 'RAJASTHAN', NULL, NULL, NULL, NULL),
(30, 'SIKKIM', NULL, NULL, NULL, NULL),
(31, 'TAMIL NADU', NULL, NULL, NULL, NULL),
(32, 'TRIPURA', NULL, NULL, NULL, NULL),
(33, 'UTTARAKHAND', NULL, NULL, NULL, NULL),
(34, 'UTTAR PRADESH', NULL, NULL, NULL, NULL),
(35, 'WEST BENGAL', NULL, NULL, NULL, NULL),
(36, 'TELANGANA', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pro_mst_status`
--

DROP TABLE IF EXISTS `pro_mst_status`;
CREATE TABLE IF NOT EXISTS `pro_mst_status` (
  `id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT,
  `status_type` tinyint(3) UNSIGNED NOT NULL COMMENT '1=App Status,2=>User Status,3=>FIRCU Status, 4 - Invoivce status, 5-Agency type',
  `status_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(3) UNSIGNED NOT NULL DEFAULT 1 COMMENT '1=>Active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pro_mst_status`
--

INSERT INTO `pro_mst_status` (`id`, `status_type`, `status_name`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 3, 'Pending', 1, NULL, NULL),
(2, 3, 'In Progress', 1, NULL, NULL),
(3, 3, 'Positive', 1, NULL, NULL),
(4, 3, 'Negative', 1, NULL, NULL),
(5, 3, 'Cancelled', 1, NULL, NULL),
(6, 3, 'Refer to credit', 1, NULL, NULL),
(7, 4, 'Pending', 1, NULL, NULL),
(8, 4, 'Approved', 1, NULL, NULL),
(9, 4, 'Disbursment Que', 1, NULL, NULL),
(10, 4, 'Sent to Bank', 1, NULL, NULL),
(11, 4, 'Failed Disbursment', 1, NULL, NULL),
(12, 4, 'Disbursed', 1, NULL, NULL),
(13, 4, 'Partially Payment Settled ', 1, NULL, NULL),
(14, 4, 'Reject', 1, NULL, NULL),
(15, 4, 'Payment Settled', 1, NULL, NULL),
(16, 5, 'FI', 1, NULL, NULL),
(17, 5, 'RCU', 1, NULL, NULL),
(18, 5, 'Inspection', 1, NULL, NULL),
(19, 1, 'New', 0, NULL, NULL),
(20, 1, 'Completed', 1, NULL, NULL),
(21, 1, 'Limit Approved', 1, NULL, NULL),
(22, 1, 'Offer Accepted', 1, NULL, NULL),
(23, 1, 'Offer Rejected', 1, NULL, NULL),
(24, 1, 'Pre Sanction Doc Uploaded', 0, NULL, NULL),
(25, 1, 'Sanction Letter Generated', 1, NULL, NULL),
(26, 1, 'Post Sanction Doc Uploaded', 1, NULL, NULL),
(27, 1, 'Disbursed', 0, NULL, NULL),
(28, 4, 'Exception Cases', 1, NULL, NULL),
(30, 6, 'Disburse Pending', 1, NULL, NULL),
(31, 6, 'Disburse Completed', 1, NULL, NULL),
(32, 6, 'Disburse Failed', 1, NULL, NULL),
(33, 7, 'Unsettled', 1, NULL, NULL),
(34, 7, 'Settled', 1, NULL, NULL),
(35, 2, 'Account Closure', 1, NULL, NULL),
(36, 9, 'New', 1, NULL, NULL),
(37, 9, 'In process', 1, NULL, NULL),
(38, 9, 'Approved', 1, NULL, NULL),
(39, 9, 'Transaction Settled', 1, NULL, NULL),
(40, 9, 'Completed', 1, NULL, NULL),
(41, 2, 'Write Off', 1, NULL, NULL),
(42, 9, 'Revert Back', 1, NULL, NULL),
(43, 1, 'Rejected', 1, NULL, NULL),
(44, 1, 'Cancelled', 1, NULL, NULL),
(45, 1, 'On Hold', 1, NULL, NULL),
(46, 1, 'Data Pending', 1, NULL, NULL),
(47, 4, 'Settle Po Invoice', 1, NULL, NULL),
(48, 1, 'NPA', 1, NULL, NULL),
(49, 1, 'Incomplete', 1, NULL, NULL),
(50, 1, 'Sanctioned', 1, NULL, NULL),
(51, 1, 'Closed', 1, NULL, NULL),
(55, 1, 'Limit Rejected', 1, NULL, NULL),
(56, 1, 'Offer Generated', 1, NULL, NULL),
(57, 1, 'Sanction Letter Approved', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pro_oauth_access_tokens`
--

DROP TABLE IF EXISTS `pro_oauth_access_tokens`;
CREATE TABLE IF NOT EXISTS `pro_oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pro_oauth_access_tokens_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pro_oauth_access_tokens`
--

INSERT INTO `pro_oauth_access_tokens` (`id`, `user_id`, `client_id`, `name`, `scopes`, `revoked`, `created_at`, `updated_at`, `expires_at`) VALUES
('438a7e5eaf2fd76394e9133e7f1730884520b85096962a66b5b55710832c114e6e8635d0d1cb6766', 1, 1, 'appToken', '[]', 1, '2021-06-22 11:03:18', '2021-06-22 11:03:18', '2022-06-22 16:33:18'),
('501c9b8abab8a6f09a41c72cd89718eab5cd3f8c6d1c122101543bfcbb37202ef460bceb918dd184', 1, 3, 'appToken', '[]', 0, '2021-06-26 05:21:33', '2021-06-26 05:21:33', '2022-06-26 10:51:33'),
('72a24231a34cc44a0b7af6197789a84220457869e4e1295d6d368f7c3e378108037db56efc4d7fc1', 1, 3, 'appToken', '[]', 0, '2021-06-25 05:30:47', '2021-06-25 05:30:47', '2022-06-25 11:00:47'),
('8a5be170b42803b96f72380a32cc1bebb9045e2a7bd946bddfedfd8073858d44f89d2185df1d8b20', 1, 3, 'appToken', '[]', 0, '2021-06-26 04:37:54', '2021-06-26 04:37:54', '2022-06-26 10:07:54'),
('a781bdacb7451b950642d4f52c7fe40e75b7dfb622c692859ff8958b1661aa1417d4ae1c7ceccd8b', 1, 1, 'appToken', '[]', 0, '2021-06-22 11:20:51', '2021-06-22 11:20:51', '2022-06-22 16:50:51'),
('b0b37895b4a35ff6a898a69c8e61cdd98b603f859316f49155968d3b5a8d0d0c0e8f730efff6f871', 2, 3, 'appToken', '[]', 0, '2021-06-26 05:20:18', '2021-06-26 05:20:18', '2022-06-26 10:50:18'),
('b95b9b8908b90c3b59691909bb84e34830643e011d46b52b9628822f32207d252cd6fcd51f1d3af8', 1, 3, 'appToken', '[]', 0, '2021-06-25 05:27:44', '2021-06-25 05:27:44', '2022-06-25 10:57:44'),
('d7895543b4c24f24147b4db34ffe7d4fedad9860b60c4d7386f7457d308358c75d0a56fa81107e27', 3, 3, 'appToken', '[]', 0, '2021-06-26 05:58:41', '2021-06-26 05:58:41', '2022-06-26 11:28:41'),
('f56d2a8125db5354874b8ccd07050e4b596976f1d8e97fd1a041a763a5ed69a05e946b232560abed', 3, 3, 'appToken', '[]', 0, '2021-06-26 05:57:37', '2021-06-26 05:57:37', '2022-06-26 11:27:37');

-- --------------------------------------------------------

--
-- Table structure for table `pro_oauth_auth_codes`
--

DROP TABLE IF EXISTS `pro_oauth_auth_codes`;
CREATE TABLE IF NOT EXISTS `pro_oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pro_oauth_auth_codes_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pro_oauth_clients`
--

DROP TABLE IF EXISTS `pro_oauth_clients`;
CREATE TABLE IF NOT EXISTS `pro_oauth_clients` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pro_oauth_clients_user_id_index` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pro_oauth_clients`
--

INSERT INTO `pro_oauth_clients` (`id`, `user_id`, `name`, `secret`, `provider`, `redirect`, `personal_access_client`, `password_client`, `revoked`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Laravel Personal Access Client', 'F3RDJmpxrhIThOft7INf7NyXTSbfIP6ZSQ1od2MD', NULL, 'http://localhost', 1, 0, 0, '2021-06-22 09:06:47', '2021-06-22 09:06:47'),
(2, NULL, 'Laravel Password Grant Client', 'YvDt3WRDQS12eC2j0wPDDvDJz7I8xBSkCmMQIz6i', 'users', 'http://localhost', 0, 1, 0, '2021-06-22 09:06:47', '2021-06-22 09:06:47'),
(3, NULL, 'Laravel Personal Access Client', 'j63stWbnVrnEKoi6KXolmdNuPPHYYPlkv22Rd83u', NULL, 'http://localhost', 1, 0, 0, '2021-06-25 03:08:56', '2021-06-25 03:08:56'),
(4, NULL, 'Laravel Password Grant Client', 'VNaUEG3YWVfj7AWlkSy2pQHCJo6pKT8aAWL8bSTD', 'users', 'http://localhost', 0, 1, 0, '2021-06-25 03:08:57', '2021-06-25 03:08:57');

-- --------------------------------------------------------

--
-- Table structure for table `pro_oauth_personal_access_clients`
--

DROP TABLE IF EXISTS `pro_oauth_personal_access_clients`;
CREATE TABLE IF NOT EXISTS `pro_oauth_personal_access_clients` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pro_oauth_personal_access_clients`
--

INSERT INTO `pro_oauth_personal_access_clients` (`id`, `client_id`, `created_at`, `updated_at`) VALUES
(1, 1, '2021-06-22 09:06:47', '2021-06-22 09:06:47'),
(2, 3, '2021-06-25 03:08:57', '2021-06-25 03:08:57');

-- --------------------------------------------------------

--
-- Table structure for table `pro_oauth_refresh_tokens`
--

DROP TABLE IF EXISTS `pro_oauth_refresh_tokens`;
CREATE TABLE IF NOT EXISTS `pro_oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pro_oauth_refresh_tokens_access_token_id_index` (`access_token_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pro_password_resets`
--

DROP TABLE IF EXISTS `pro_password_resets`;
CREATE TABLE IF NOT EXISTS `pro_password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `pro_password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pro_user`
--

DROP TABLE IF EXISTS `pro_user`;
CREATE TABLE IF NOT EXISTS `pro_user` (
  `user_id` int(10) NOT NULL AUTO_INCREMENT,
  `comp_id` int(10) UNSIGNED DEFAULT NULL,
  `f_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `m_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `l_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile_no` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_type` tinyint(1) NOT NULL DEFAULT 2 COMMENT '1=> Backend, 2=>Frontend',
  `password` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_email_verified` tinyint(1) DEFAULT NULL COMMENT '0=>Not Verified,1 =>Verified',
  `email_verified_updatetime` datetime DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_mobile_verified` tinyint(1) DEFAULT NULL COMMENT '0=>Not Verified,1 =>Verified',
  `otp_verified_updatetime` datetime DEFAULT NULL,
  `is_pwd_changed` tinyint(1) DEFAULT NULL COMMENT '0=>Not Changed, 1=> Changed',
  `pwd_updatetime` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1=>Active ,0 =>In Active',
  `block_status_id` tinyint(4) DEFAULT NULL,
  `block_status_updatetime` datetime DEFAULT NULL,
  `parent_id` int(10) UNSIGNED DEFAULT NULL,
  `is_assigned` tinyint(3) UNSIGNED NOT NULL DEFAULT 2 COMMENT '1=>Assigned,2=>Not Assigned',
  `created_by` int(10) UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(10) UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pro_user`
--

INSERT INTO `pro_user` (`user_id`, `comp_id`, `f_name`, `m_name`, `l_name`, `email`, `mobile_no`, `user_type`, `password`, `is_email_verified`, `email_verified_updatetime`, `remember_token`, `is_mobile_verified`, `otp_verified_updatetime`, `is_pwd_changed`, `pwd_updatetime`, `is_active`, `block_status_id`, `block_status_updatetime`, `parent_id`, `is_assigned`, `created_by`, `created_at`, `updated_at`, `updated_by`) VALUES
(1, 1, 'vishal', NULL, 'dubey', NULL, '4987654321', 2, '$2y$10$qcl//CR8g.mCqxQEktHI.O/8GMxfclLanWnCIBkqqu2CoHG7cpHiy', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, 2, NULL, '2021-06-22 11:03:18', '2021-06-30 01:00:10', NULL),
(2, NULL, NULL, NULL, NULL, NULL, '9827512345', 2, '$2y$10$1D7laGqHdUTx6uCzSYD5KOlIn.TAPZ4u8NqcP.0aqwzmuQUr8Vywy', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, 2, NULL, '2021-06-26 05:20:18', '2021-06-26 05:20:18', NULL),
(3, NULL, NULL, NULL, NULL, NULL, '4987654322', 2, '$2y$10$Tb9wzsqE9jmeMU2H1rX60u.kLebudJqLP1oIB2qy3kj7F.s93Scdu', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, 2, NULL, '2021-06-26 05:57:37', '2021-06-26 05:57:37', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pro_user_addr`
--

DROP TABLE IF EXISTS `pro_user_addr`;
CREATE TABLE IF NOT EXISTS `pro_user_addr` (
  `user_addr_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(10) UNSIGNED NOT NULL,
  `addr1` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `addr2` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state_id` int(3) NOT NULL,
  `pincode` varchar(6) COLLATE utf8mb4_unicode_ci NOT NULL,
  `addr_type` tinyint(1) NOT NULL COMMENT '0->Perm, 1->corr',
  `is_addr_same` tinyint(1) UNSIGNED DEFAULT 0 COMMENT '0-> Not Same, 1, Same',
  `created_by` int(10) UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(10) UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  PRIMARY KEY (`user_addr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pro_user_bank_detail`
--

DROP TABLE IF EXISTS `pro_user_bank_detail`;
CREATE TABLE IF NOT EXISTS `pro_user_bank_detail` (
  `user_bank_detail_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(10) UNSIGNED NOT NULL,
  `bank_acc_no` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ifsc_code` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `branch_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(10) UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(10) UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  PRIMARY KEY (`user_bank_detail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pro_user_consent`
--

DROP TABLE IF EXISTS `pro_user_consent`;
CREATE TABLE IF NOT EXISTS `pro_user_consent` (
  `user_consent_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(10) UNSIGNED NOT NULL,
  `device_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `device_info` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(3) UNSIGNED NOT NULL DEFAULT 0 COMMENT '1=> Active',
  `created_by` int(10) UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(10) UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  PRIMARY KEY (`user_consent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pro_user_info`
--

DROP TABLE IF EXISTS `pro_user_info`;
CREATE TABLE IF NOT EXISTS `pro_user_info` (
  `user_info_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(10) UNSIGNED NOT NULL,
  `user_dob` date DEFAULT NULL,
  `gender` tinyint(3) UNSIGNED DEFAULT NULL,
  `lang_option` tinyint(3) UNSIGNED DEFAULT NULL,
  `pan_no` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pan_f_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pan_m_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pan_l_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pincode` varchar(6) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_married` tinyint(3) UNSIGNED DEFAULT NULL,
  `is_employed` tinyint(3) UNSIGNED DEFAULT NULL,
  `employment_type` tinyint(3) UNSIGNED DEFAULT NULL COMMENT '1-> self employeed,2, Salaried',
  `mode_of_salary` int(2) DEFAULT NULL COMMENT '1->Cash, 2->Cheque, 3->Direct Bank',
  `monthly_salary` float DEFAULT NULL,
  `monthly_income` float DEFAULT NULL,
  `created_by` int(10) UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(10) UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  PRIMARY KEY (`user_info_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pro_user_info`
--

INSERT INTO `pro_user_info` (`user_info_id`, `user_id`, `user_dob`, `gender`, `lang_option`, `pan_no`, `pan_f_name`, `pan_m_name`, `pan_l_name`, `pincode`, `is_married`, `is_employed`, `employment_type`, `mode_of_salary`, `monthly_salary`, `monthly_income`, `created_by`, `created_at`, `updated_at`, `updated_by`) VALUES
(1, 1, NULL, 1, NULL, 'AOSPD1231N', NULL, NULL, NULL, '455002', NULL, NULL, 0, 1, 55000, NULL, NULL, '2021-06-25 06:19:07', '2021-06-30 01:00:10', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pro_user_kyc_doc`
--

DROP TABLE IF EXISTS `pro_user_kyc_doc`;
CREATE TABLE IF NOT EXISTS `pro_user_kyc_doc` (
  `kyc_doc_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(10) UNSIGNED NOT NULL,
  `kyc_type` tinyint(3) UNSIGNED NOT NULL COMMENT '1=>Pan,2=>Aadhar,3=>Voter',
  `doc_id` smallint(5) UNSIGNED NOT NULL,
  `kyc_doc_id_no` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lang_option` tinyint(3) UNSIGNED NOT NULL,
  `f_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `m_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `l_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_verified` tinyint(3) UNSIGNED NOT NULL COMMENT '1=>verfied,0=> un verified',
  `verified_auto` tinyint(3) UNSIGNED NOT NULL COMMENT '1=> Autp,2=>manual',
  `api_log_id` int(10) UNSIGNED DEFAULT NULL,
  `is_active` tinyint(3) UNSIGNED NOT NULL DEFAULT 0 COMMENT '1=> Active',
  `created_by` int(10) UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(10) UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  PRIMARY KEY (`kyc_doc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pro_user_otp`
--

DROP TABLE IF EXISTS `pro_user_otp`;
CREATE TABLE IF NOT EXISTS `pro_user_otp` (
  `user_otp_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(10) UNSIGNED NOT NULL,
  `mobile_no` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `otp` int(10) UNSIGNED NOT NULL,
  `retery_count` tinyint(3) UNSIGNED NOT NULL,
  `is_active` tinyint(3) UNSIGNED NOT NULL DEFAULT 0 COMMENT '1=> Active',
  `vatid_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_by` int(10) UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(10) UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  PRIMARY KEY (`user_otp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pro_user_ref`
--

DROP TABLE IF EXISTS `pro_user_ref`;
CREATE TABLE IF NOT EXISTS `pro_user_ref` (
  `user_ref_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(10) UNSIGNED NOT NULL,
  `ref_name_1` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_mobile_1` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_name_2` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_mobile_2` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(10) UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(10) UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  PRIMARY KEY (`user_ref_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
