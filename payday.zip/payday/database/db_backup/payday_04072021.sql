-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 04, 2021 at 04:23 PM
-- Server version: 8.0.25-0ubuntu0.20.04.1
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `payday_dev_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `pro_activity_log`
--

CREATE TABLE `pro_activity_log` (
  `activity_log_id` int UNSIGNED NOT NULL,
  `activity_id` smallint UNSIGNED NOT NULL,
  `activity_desc` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_address` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `route_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int UNSIGNED DEFAULT NULL,
  `app_id` int UNSIGNED DEFAULT NULL,
  `email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `browser_info` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `source` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `device_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` int UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_by` int UNSIGNED NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pro_api_log`
--

CREATE TABLE `pro_api_log` (
  `api_log_id` int UNSIGNED NOT NULL,
  `user_id` int UNSIGNED NOT NULL,
  `doc_id` smallint UNSIGNED NOT NULL,
  `doc_id_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `api_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `req_txt` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `res_txt` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ipaddr` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  `api_url` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_verified` tinyint UNSIGNED NOT NULL COMMENT '1=>verfied,0=> un verified',
  `created_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pro_app`
--

CREATE TABLE `pro_app` (
  `app_id` int UNSIGNED NOT NULL,
  `user_id` int UNSIGNED NOT NULL,
  `is_active` tinyint UNSIGNED NOT NULL DEFAULT '0' COMMENT '1=> Active',
  `app_status_id` smallint UNSIGNED NOT NULL,
  `created_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pro_app_info`
--

CREATE TABLE `pro_app_info` (
  `app_id` int UNSIGNED NOT NULL,
  `user_id` int UNSIGNED NOT NULL,
  `created_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pro_app_status`
--

CREATE TABLE `pro_app_status` (
  `app_status_id` int UNSIGNED NOT NULL,
  `app_id` int UNSIGNED NOT NULL,
  `status_id` smallint UNSIGNED NOT NULL,
  `cmt_txt` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pro_company`
--

CREATE TABLE `pro_company` (
  `comp_id` int UNSIGNED NOT NULL,
  `name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pro_company`
--

INSERT INTO `pro_company` (`comp_id`, `name`, `created_by`, `created_at`, `updated_at`, `updated_by`) VALUES
(1, 'ABC Pvt Ltd', NULL, '2021-06-25 06:44:10', '2021-06-25 06:44:10', NULL),
(2, 'ATS Pvt Ltd', NULL, '2021-06-26 05:22:39', '2021-06-26 05:22:39', NULL),
(3, 'XYZ infosystems', NULL, '2021-06-26 06:03:00', '2021-06-26 06:03:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pro_failed_jobs`
--

CREATE TABLE `pro_failed_jobs` (
  `id` bigint UNSIGNED NOT NULL,
  `uuid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pro_file`
--

CREATE TABLE `pro_file` (
  `file_id` int UNSIGNED NOT NULL,
  `file_type` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `file_name` varchar(100) NOT NULL,
  `file_size` int UNSIGNED NOT NULL,
  `file_path` varchar(100) NOT NULL,
  `created_by` int UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `pro_migrations`
--

CREATE TABLE `pro_migrations` (
  `id` int UNSIGNED NOT NULL,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pro_migrations`
--

INSERT INTO `pro_migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2016_06_01_000001_create_oauth_auth_codes_table', 1),
(4, '2016_06_01_000002_create_oauth_access_tokens_table', 1),
(5, '2016_06_01_000003_create_oauth_refresh_tokens_table', 1),
(6, '2016_06_01_000004_create_oauth_clients_table', 1),
(7, '2016_06_01_000005_create_oauth_personal_access_clients_table', 1),
(8, '2019_08_19_000000_create_failed_jobs_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `pro_mst_activity`
--

CREATE TABLE `pro_mst_activity` (
  `id` smallint UNSIGNED NOT NULL,
  `route_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `activity_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `activity_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint UNSIGNED NOT NULL,
  `created_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pro_mst_activity`
--

INSERT INTO `pro_mst_activity` (`id`, `route_name`, `activity_code`, `activity_name`, `is_active`, `created_by`, `created_at`, `updated_at`) VALUES
(1, '', 'frontend_reg', 'FrontendRegistration', 1, 1, NULL, NULL),
(2, '', 'email_verified', 'Email Verified', 1, NULL, NULL, NULL),
(3, '', 'mobile_otp_verified', 'mobile_otp_verified', 1, NULL, NULL, NULL),
(4, '', 'login', 'Login', 1, NULL, NULL, NULL),
(5, '', 'first_time_password_change', 'first_time_password_change', 1, NULL, NULL, NULL),
(6, '', 'supplier_form_sbumit', 'supplier_form_sbumit', 1, NULL, NULL, NULL),
(7, '', 'change_pwd', 'change_pwd', 1, NULL, NULL, NULL),
(8, '', 'forget_pwd', 'forget_pwd', 1, NULL, NULL, NULL),
(9, '', 'invpice_upload', 'invpice_upload', 1, NULL, NULL, NULL),
(10, '', 'tally_posting', 'tally_posting', 1, NULL, NULL, NULL),
(11, '', 'offer_creation', 'offer_creation', 1, NULL, NULL, NULL),
(12, '', 'user_limit_enhancement', 'user_limit_enhancement', 1, NULL, NULL, NULL),
(13, '', 'user_product_limit_enhancement', 'user_product_limit_enhancement', 1, NULL, NULL, NULL),
(14, '', 'invoice_send_to_disburesement', 'Invoice_send_to_disburesement', 1, NULL, NULL, NULL),
(15, '', 'invoice_Upload_manul_single', 'Invoice_Upload_manul_single', 1, NULL, NULL, NULL),
(16, ' ', 'application_renewal', 'Application Renewal', 1, 1, '2020-04-29 18:30:00', NULL),
(17, ' ', 'app_status_changed', 'Application Status Changed', 1, 1, '2020-04-30 00:00:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pro_mst_doc`
--

CREATE TABLE `pro_mst_doc` (
  `id` smallint UNSIGNED NOT NULL,
  `wf_stage_id` int UNSIGNED NOT NULL,
  `doc_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `doc_name` varchar(250) NOT NULL,
  `is_active` tinyint UNSIGNED NOT NULL DEFAULT '1',
  `created_by` int UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `pro_mst_doc`
--

INSERT INTO `pro_mst_doc` (`id`, `wf_stage_id`, `doc_type`, `doc_name`, `is_active`, `created_by`, `created_at`, `updated_at`, `updated_by`) VALUES
(1, 8, 'Adhaar', 'adhaar front', 1, NULL, '2021-07-03 07:52:16', '2021-07-03 09:38:07', NULL),
(2, 8, 'Adhaar', 'adhaar back', 1, NULL, '2021-07-03 07:52:30', '2021-07-03 09:38:12', NULL),
(3, 9, 'PAN', 'pan', 1, NULL, '2021-07-03 07:53:41', '2021-07-03 09:38:16', NULL),
(4, 10, 'Selfie', 'selfie', 1, NULL, '2021-07-03 07:53:41', '2021-07-03 09:38:20', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pro_mst_lang`
--

CREATE TABLE `pro_mst_lang` (
  `id` int UNSIGNED NOT NULL,
  `lang_type` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `lang_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `lang_dir` enum('ltr','rtl') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ltr',
  `file_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_path` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pro_mst_lang`
--

INSERT INTO `pro_mst_lang` (`id`, `lang_type`, `lang_name`, `lang_dir`, `file_name`, `file_path`, `created_by`, `created_at`, `updated_at`, `updated_by`) VALUES
(1, 'en', 'English', 'ltr', 'en.png', 'images/lang-icons', NULL, NULL, NULL, NULL),
(2, 'hi', 'Hindi', 'ltr', NULL, 'images/lang-icons', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pro_mst_sal_mode`
--

CREATE TABLE `pro_mst_sal_mode` (
  `id` int UNSIGNED NOT NULL,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pro_mst_sal_mode`
--

INSERT INTO `pro_mst_sal_mode` (`id`, `name`, `created_by`, `created_at`, `updated_at`, `updated_by`) VALUES
(1, 'Cheque', NULL, NULL, NULL, NULL),
(2, 'Cash', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pro_mst_state`
--

CREATE TABLE `pro_mst_state` (
  `id` int UNSIGNED NOT NULL,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pro_mst_state`
--

INSERT INTO `pro_mst_state` (`id`, `name`, `created_by`, `created_at`, `updated_at`, `updated_by`) VALUES
(1, 'ANDAMAN AND NICOBAR ISLANDS', NULL, NULL, NULL, NULL),
(2, 'ANDHRA PRADESH', NULL, NULL, NULL, NULL),
(3, 'ARUNACHAL PRADESH', NULL, NULL, NULL, NULL),
(4, 'ASSAM', NULL, NULL, NULL, NULL),
(5, 'BIHAR', NULL, NULL, NULL, NULL),
(6, 'CHATTISGARH', NULL, NULL, NULL, NULL),
(7, 'CHANDIGARH', NULL, NULL, NULL, NULL),
(8, 'DAMAN AND DIU', NULL, NULL, NULL, NULL),
(9, 'DELHI', NULL, NULL, NULL, NULL),
(10, 'DADRA AND NAGAR HAVELI', NULL, NULL, NULL, NULL),
(11, 'GOA', NULL, NULL, NULL, NULL),
(12, 'GUJARAT', NULL, NULL, NULL, NULL),
(13, 'HIMACHAL PRADESH', NULL, NULL, NULL, NULL),
(14, 'HARYANA', NULL, NULL, NULL, NULL),
(15, 'JAMMU AND KASHMIR', NULL, NULL, NULL, NULL),
(16, 'JHARKHAND', NULL, NULL, NULL, NULL),
(17, 'KERALA', NULL, NULL, NULL, NULL),
(18, 'KARNATAKA', NULL, NULL, NULL, NULL),
(19, 'LAKSHADWEEP', NULL, NULL, NULL, NULL),
(20, 'MEGHALAYA', NULL, NULL, NULL, NULL),
(21, 'MAHARASHTRA', NULL, NULL, NULL, NULL),
(22, 'MANIPUR', NULL, NULL, NULL, NULL),
(23, 'MADHYA PRADESH', NULL, NULL, NULL, NULL),
(24, 'MIZORAM', NULL, NULL, NULL, NULL),
(25, 'NAGALAND', NULL, NULL, NULL, NULL),
(26, 'ORISSA', NULL, NULL, NULL, NULL),
(27, 'PUNJAB', NULL, NULL, NULL, NULL),
(28, 'PONDICHERRY', NULL, NULL, NULL, NULL),
(29, 'RAJASTHAN', NULL, NULL, NULL, NULL),
(30, 'SIKKIM', NULL, NULL, NULL, NULL),
(31, 'TAMIL NADU', NULL, NULL, NULL, NULL),
(32, 'TRIPURA', NULL, NULL, NULL, NULL),
(33, 'UTTARAKHAND', NULL, NULL, NULL, NULL),
(34, 'UTTAR PRADESH', NULL, NULL, NULL, NULL),
(35, 'WEST BENGAL', NULL, NULL, NULL, NULL),
(36, 'TELANGANA', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pro_mst_status`
--

CREATE TABLE `pro_mst_status` (
  `id` tinyint UNSIGNED NOT NULL,
  `status_type` tinyint UNSIGNED NOT NULL COMMENT '1=App Status,2=>User Status,3=>FIRCU Status, 4 - Invoivce status, 5-Agency type',
  `status_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint UNSIGNED NOT NULL DEFAULT '1' COMMENT '1=>Active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pro_mst_status`
--

INSERT INTO `pro_mst_status` (`id`, `status_type`, `status_name`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 3, 'Pending', 1, NULL, NULL),
(2, 3, 'In Progress', 1, NULL, NULL),
(3, 3, 'Positive', 1, NULL, NULL),
(4, 3, 'Negative', 1, NULL, NULL),
(5, 3, 'Cancelled', 1, NULL, NULL),
(6, 3, 'Refer to credit', 1, NULL, NULL),
(7, 4, 'Pending', 1, NULL, NULL),
(8, 4, 'Approved', 1, NULL, NULL),
(9, 4, 'Disbursment Que', 1, NULL, NULL),
(10, 4, 'Sent to Bank', 1, NULL, NULL),
(11, 4, 'Failed Disbursment', 1, NULL, NULL),
(12, 4, 'Disbursed', 1, NULL, NULL),
(13, 4, 'Partially Payment Settled ', 1, NULL, NULL),
(14, 4, 'Reject', 1, NULL, NULL),
(15, 4, 'Payment Settled', 1, NULL, NULL),
(16, 5, 'FI', 1, NULL, NULL),
(17, 5, 'RCU', 1, NULL, NULL),
(18, 5, 'Inspection', 1, NULL, NULL),
(19, 1, 'New', 0, NULL, NULL),
(20, 1, 'Completed', 1, NULL, NULL),
(21, 1, 'Limit Approved', 1, NULL, NULL),
(22, 1, 'Offer Accepted', 1, NULL, NULL),
(23, 1, 'Offer Rejected', 1, NULL, NULL),
(24, 1, 'Pre Sanction Doc Uploaded', 0, NULL, NULL),
(25, 1, 'Sanction Letter Generated', 1, NULL, NULL),
(26, 1, 'Post Sanction Doc Uploaded', 1, NULL, NULL),
(27, 1, 'Disbursed', 0, NULL, NULL),
(28, 4, 'Exception Cases', 1, NULL, NULL),
(30, 6, 'Disburse Pending', 1, NULL, NULL),
(31, 6, 'Disburse Completed', 1, NULL, NULL),
(32, 6, 'Disburse Failed', 1, NULL, NULL),
(33, 7, 'Unsettled', 1, NULL, NULL),
(34, 7, 'Settled', 1, NULL, NULL),
(35, 2, 'Account Closure', 1, NULL, NULL),
(36, 9, 'New', 1, NULL, NULL),
(37, 9, 'In process', 1, NULL, NULL),
(38, 9, 'Approved', 1, NULL, NULL),
(39, 9, 'Transaction Settled', 1, NULL, NULL),
(40, 9, 'Completed', 1, NULL, NULL),
(41, 2, 'Write Off', 1, NULL, NULL),
(42, 9, 'Revert Back', 1, NULL, NULL),
(43, 1, 'Rejected', 1, NULL, NULL),
(44, 1, 'Cancelled', 1, NULL, NULL),
(45, 1, 'On Hold', 1, NULL, NULL),
(46, 1, 'Data Pending', 1, NULL, NULL),
(47, 4, 'Settle Po Invoice', 1, NULL, NULL),
(48, 1, 'NPA', 1, NULL, NULL),
(49, 1, 'Incomplete', 1, NULL, NULL),
(50, 1, 'Sanctioned', 1, NULL, NULL),
(51, 1, 'Closed', 1, NULL, NULL),
(55, 1, 'Limit Rejected', 1, NULL, NULL),
(56, 1, 'Offer Generated', 1, NULL, NULL),
(57, 1, 'Sanction Letter Approved', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pro_oauth_access_tokens`
--

CREATE TABLE `pro_oauth_access_tokens` (
  `id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `client_id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pro_oauth_access_tokens`
--

INSERT INTO `pro_oauth_access_tokens` (`id`, `user_id`, `client_id`, `name`, `scopes`, `revoked`, `created_at`, `updated_at`, `expires_at`) VALUES
('152d2abd328826014e25774f3e4976de80af7f8ee62f25019a8c69f87045c1a9bd6859fc36bc3077', 4, 3, 'appToken', '[]', 0, '2021-07-01 06:08:48', '2021-07-01 06:08:48', '2021-07-01 11:48:48'),
('192b61dfda3d9f406f457688aad03a57f820c01f833860a1ad57c6c124ca9f78e4a89276b15441d4', 5, 3, 'appToken', '[]', 0, '2021-07-03 05:03:54', '2021-07-03 05:03:54', '2021-07-03 10:43:54'),
('28ad66a2ca5d5eacc9f7d5a224a16edfee9d8472522ea91baf5bf1f2f0bed508d0f3a45651689a2e', 6, 3, 'appToken', '[]', 0, '2021-07-03 05:20:28', '2021-07-03 05:20:28', '2021-07-03 11:00:28'),
('438a7e5eaf2fd76394e9133e7f1730884520b85096962a66b5b55710832c114e6e8635d0d1cb6766', 1, 1, 'appToken', '[]', 1, '2021-06-22 11:03:18', '2021-06-22 11:03:18', '2022-06-22 16:33:18'),
('440e9050525fbb6b8baf5bf4f84ce70fd4b12219a5bd2a6da862223187ca2ada3fad92b805122bad', 4, 3, 'appToken', '[]', 0, '2021-07-01 06:42:37', '2021-07-01 06:42:37', '2021-07-01 12:22:37'),
('501c9b8abab8a6f09a41c72cd89718eab5cd3f8c6d1c122101543bfcbb37202ef460bceb918dd184', 1, 3, 'appToken', '[]', 0, '2021-06-26 05:21:33', '2021-06-26 05:21:33', '2022-06-26 10:51:33'),
('72a24231a34cc44a0b7af6197789a84220457869e4e1295d6d368f7c3e378108037db56efc4d7fc1', 1, 3, 'appToken', '[]', 0, '2021-06-25 05:30:47', '2021-06-25 05:30:47', '2022-06-25 11:00:47'),
('87bf81fc6dab843db3a33c85f0c3c1af53b53611f4b91ea11af5c93912b4e27f52a7e752e5924030', 4, 3, 'appToken', '[]', 1, '2021-07-01 06:05:39', '2021-07-01 06:05:39', '2021-07-01 11:45:39'),
('8a5be170b42803b96f72380a32cc1bebb9045e2a7bd946bddfedfd8073858d44f89d2185df1d8b20', 1, 3, 'appToken', '[]', 0, '2021-06-26 04:37:54', '2021-06-26 04:37:54', '2022-06-26 10:07:54'),
('9aeaf156ef90d7e2c49068dba3d22d8da767705c38ef1ccae666692808d07c1c9eea83775c4c6566', 5, 3, 'appToken', '[]', 0, '2021-07-03 07:08:21', '2021-07-03 07:08:21', '2021-07-03 14:18:21'),
('a781bdacb7451b950642d4f52c7fe40e75b7dfb622c692859ff8958b1661aa1417d4ae1c7ceccd8b', 1, 1, 'appToken', '[]', 0, '2021-06-22 11:20:51', '2021-06-22 11:20:51', '2022-06-22 16:50:51'),
('b0b37895b4a35ff6a898a69c8e61cdd98b603f859316f49155968d3b5a8d0d0c0e8f730efff6f871', 2, 3, 'appToken', '[]', 0, '2021-06-26 05:20:18', '2021-06-26 05:20:18', '2022-06-26 10:50:18'),
('b59abb272dfed131d6b4db10bb25e1af6e5f7634642c16b40a258ede35cde91c03c957af201a8086', 4, 3, 'appToken', '[]', 0, '2021-07-01 06:31:50', '2021-07-01 06:31:50', '2021-07-01 12:11:50'),
('b95b9b8908b90c3b59691909bb84e34830643e011d46b52b9628822f32207d252cd6fcd51f1d3af8', 1, 3, 'appToken', '[]', 0, '2021-06-25 05:27:44', '2021-06-25 05:27:44', '2022-06-25 10:57:44'),
('d7895543b4c24f24147b4db34ffe7d4fedad9860b60c4d7386f7457d308358c75d0a56fa81107e27', 3, 3, 'appToken', '[]', 0, '2021-06-26 05:58:41', '2021-06-26 05:58:41', '2022-06-26 11:28:41'),
('e0d991b4b115976d2deb9aa1b7caf4c2e1136ba926b34f4204478c43be6c67d196fdaa87e0285340', 5, 3, 'appToken', '[]', 0, '2021-07-03 09:26:22', '2021-07-03 09:26:22', '2021-07-03 16:36:22'),
('e325e4e0232064c8bf464e3aa03cc22877c8a721ed162f165b84151e61f0c543f0519d23fd9ecdea', 5, 3, 'appToken', '[]', 0, '2021-07-03 06:25:58', '2021-07-03 06:25:58', '2021-07-03 12:05:58'),
('f05108a95642e582ad18ae472c2b3892078c1ba5ac60c1b22e052fef93ad837e701aacdd4f20fa89', 5, 3, 'appToken', '[]', 0, '2021-07-03 07:04:38', '2021-07-03 07:04:38', '2021-07-03 14:14:38'),
('f56d2a8125db5354874b8ccd07050e4b596976f1d8e97fd1a041a763a5ed69a05e946b232560abed', 3, 3, 'appToken', '[]', 0, '2021-06-26 05:57:37', '2021-06-26 05:57:37', '2022-06-26 11:27:37');

-- --------------------------------------------------------

--
-- Table structure for table `pro_oauth_auth_codes`
--

CREATE TABLE `pro_oauth_auth_codes` (
  `id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `client_id` bigint UNSIGNED NOT NULL,
  `scopes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pro_oauth_clients`
--

CREATE TABLE `pro_oauth_clients` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redirect` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pro_oauth_clients`
--

INSERT INTO `pro_oauth_clients` (`id`, `user_id`, `name`, `secret`, `provider`, `redirect`, `personal_access_client`, `password_client`, `revoked`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Laravel Personal Access Client', 'F3RDJmpxrhIThOft7INf7NyXTSbfIP6ZSQ1od2MD', NULL, 'http://localhost', 1, 0, 0, '2021-06-22 09:06:47', '2021-06-22 09:06:47'),
(2, NULL, 'Laravel Password Grant Client', 'YvDt3WRDQS12eC2j0wPDDvDJz7I8xBSkCmMQIz6i', 'users', 'http://localhost', 0, 1, 0, '2021-06-22 09:06:47', '2021-06-22 09:06:47'),
(3, NULL, 'Laravel Personal Access Client', 'j63stWbnVrnEKoi6KXolmdNuPPHYYPlkv22Rd83u', NULL, 'http://localhost', 1, 0, 0, '2021-06-25 03:08:56', '2021-06-25 03:08:56'),
(4, NULL, 'Laravel Password Grant Client', 'VNaUEG3YWVfj7AWlkSy2pQHCJo6pKT8aAWL8bSTD', 'users', 'http://localhost', 0, 1, 0, '2021-06-25 03:08:57', '2021-06-25 03:08:57');

-- --------------------------------------------------------

--
-- Table structure for table `pro_oauth_personal_access_clients`
--

CREATE TABLE `pro_oauth_personal_access_clients` (
  `id` bigint UNSIGNED NOT NULL,
  `client_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pro_oauth_personal_access_clients`
--

INSERT INTO `pro_oauth_personal_access_clients` (`id`, `client_id`, `created_at`, `updated_at`) VALUES
(1, 1, '2021-06-22 09:06:47', '2021-06-22 09:06:47'),
(2, 3, '2021-06-25 03:08:57', '2021-06-25 03:08:57');

-- --------------------------------------------------------

--
-- Table structure for table `pro_oauth_refresh_tokens`
--

CREATE TABLE `pro_oauth_refresh_tokens` (
  `id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pro_password_resets`
--

CREATE TABLE `pro_password_resets` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pro_prgm`
--

CREATE TABLE `pro_prgm` (
  `prgm_id` tinyint UNSIGNED NOT NULL,
  `prgm_name` varchar(100) NOT NULL,
  `prgm_type` tinyint UNSIGNED DEFAULT NULL COMMENT '1=>Vendor Finance , 2=>Channel Finance',
  `min_loan_size` decimal(17,2) UNSIGNED DEFAULT NULL,
  `max_loan_size` decimal(17,2) UNSIGNED DEFAULT NULL,
  `interest_rate` tinyint UNSIGNED DEFAULT NULL COMMENT '1=>Fixed , 2=>Floating',
  `overdue_interest_rate` decimal(5,2) UNSIGNED DEFAULT NULL,
  `margin` decimal(5,2) UNSIGNED DEFAULT NULL,
  `processing_fee` decimal(7,2) UNSIGNED DEFAULT NULL,
  `is_active` tinyint UNSIGNED NOT NULL DEFAULT '1' COMMENT '1=>Active,0=>In Active',
  `created_at` timestamp NULL DEFAULT NULL,
  `created_by` int UNSIGNED DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `pro_prgm`
--

INSERT INTO `pro_prgm` (`prgm_id`, `prgm_name`, `prgm_type`, `min_loan_size`, `max_loan_size`, `interest_rate`, `overdue_interest_rate`, `margin`, `processing_fee`, `is_active`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1, 'Program 1', 1, '3000.00', '10000.00', 8, '10.00', '2.00', '5000.00', 1, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pro_prgm_wf_stage`
--

CREATE TABLE `pro_prgm_wf_stage` (
  `prgm_wf_stage_id` int UNSIGNED NOT NULL,
  `prgm_id` int UNSIGNED NOT NULL,
  `wf_stage_id` int UNSIGNED NOT NULL,
  `created_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pro_prgm_wf_stage`
--

INSERT INTO `pro_prgm_wf_stage` (`prgm_wf_stage_id`, `prgm_id`, `wf_stage_id`, `created_by`, `created_at`, `updated_at`, `updated_by`) VALUES
(1, 1, 1, NULL, NULL, NULL, NULL),
(2, 1, 2, NULL, NULL, NULL, NULL),
(3, 1, 3, NULL, NULL, NULL, NULL),
(4, 1, 4, NULL, NULL, NULL, NULL),
(5, 1, 5, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pro_user`
--

CREATE TABLE `pro_user` (
  `user_id` int NOT NULL,
  `comp_id` int UNSIGNED DEFAULT NULL,
  `f_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `m_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `l_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile_no` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_type` tinyint(1) NOT NULL DEFAULT '2' COMMENT '1=> Backend, 2=>Frontend',
  `password` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_email_verified` tinyint(1) DEFAULT NULL COMMENT '0=>Not Verified,1 =>Verified',
  `email_verified_updatetime` datetime DEFAULT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_mobile_verified` tinyint(1) DEFAULT NULL COMMENT '0=>Not Verified,1 =>Verified',
  `otp_verified_updatetime` datetime DEFAULT NULL,
  `is_pwd_changed` tinyint(1) DEFAULT NULL COMMENT '0=>Not Changed, 1=> Changed',
  `pwd_updatetime` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=>Active ,0 =>In Active',
  `block_status_id` tinyint DEFAULT NULL,
  `block_status_updatetime` datetime DEFAULT NULL,
  `parent_id` int UNSIGNED DEFAULT NULL,
  `is_assigned` tinyint UNSIGNED NOT NULL DEFAULT '2' COMMENT '1=>Assigned,2=>Not Assigned',
  `created_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pro_user`
--

INSERT INTO `pro_user` (`user_id`, `comp_id`, `f_name`, `m_name`, `l_name`, `email`, `mobile_no`, `user_type`, `password`, `is_email_verified`, `email_verified_updatetime`, `remember_token`, `is_mobile_verified`, `otp_verified_updatetime`, `is_pwd_changed`, `pwd_updatetime`, `is_active`, `block_status_id`, `block_status_updatetime`, `parent_id`, `is_assigned`, `created_by`, `created_at`, `updated_at`, `updated_by`) VALUES
(1, 1, 'Anuj', 'Kumar', 'Chauhan', NULL, '9999999999', 2, '$2y$10$qcl//CR8g.mCqxQEktHI.O/8GMxfclLanWnCIBkqqu2CoHG7cpHiy', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, 2, NULL, '2021-06-22 05:33:18', '2021-06-29 19:30:10', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pro_user_addr`
--

CREATE TABLE `pro_user_addr` (
  `user_addr_id` int UNSIGNED NOT NULL,
  `user_id` int UNSIGNED NOT NULL,
  `addr1` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `addr2` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state_id` int NOT NULL,
  `pincode` varchar(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `addr_type` tinyint(1) NOT NULL COMMENT '0->Perm, 1->corr',
  `is_addr_same` tinyint UNSIGNED DEFAULT '0' COMMENT '0-> Not Same, 1, Same',
  `created_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pro_user_bank_detail`
--

CREATE TABLE `pro_user_bank_detail` (
  `user_bank_detail_id` int UNSIGNED NOT NULL,
  `user_id` int UNSIGNED NOT NULL,
  `bank_acc_no` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ifsc_code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `branch_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pro_user_consent`
--

CREATE TABLE `pro_user_consent` (
  `user_consent_id` int UNSIGNED NOT NULL,
  `user_id` int UNSIGNED NOT NULL,
  `device_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `device_info` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint UNSIGNED NOT NULL DEFAULT '0' COMMENT '1=> Active',
  `created_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pro_user_info`
--

CREATE TABLE `pro_user_info` (
  `user_info_id` int UNSIGNED NOT NULL,
  `user_id` int UNSIGNED NOT NULL,
  `user_dob` date DEFAULT NULL,
  `gender` tinyint UNSIGNED DEFAULT NULL,
  `lang_option` tinyint UNSIGNED DEFAULT NULL,
  `pan_no` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pan_f_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pan_m_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pan_l_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pincode` varchar(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_married` tinyint UNSIGNED DEFAULT NULL,
  `is_employed` tinyint UNSIGNED DEFAULT NULL,
  `employment_type` tinyint UNSIGNED DEFAULT NULL COMMENT '1-> self employeed,2, Salaried',
  `mode_of_salary` int DEFAULT NULL COMMENT '1->Cash, 2->Cheque, 3->Direct Bank',
  `monthly_salary` float DEFAULT NULL,
  `monthly_income` float DEFAULT NULL,
  `created_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pro_user_kyc_doc`
--

CREATE TABLE `pro_user_kyc_doc` (
  `user_kyc_doc_id` int UNSIGNED NOT NULL,
  `user_id` int UNSIGNED NOT NULL,
  `file_id` int UNSIGNED NOT NULL,
  `mst_doc_id` int UNSIGNED NOT NULL,
  `doc_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `f_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `m_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `l_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_verified` tinyint UNSIGNED NOT NULL DEFAULT '0' COMMENT '1=>Verfied,0=>Not verified',
  `verified_auto` tinyint UNSIGNED NOT NULL DEFAULT '2' COMMENT '1=> Auto,2=>Manual',
  `api_log_id` int UNSIGNED DEFAULT NULL,
  `is_active` tinyint UNSIGNED NOT NULL DEFAULT '0' COMMENT '1=> Active',
  `created_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pro_user_otp`
--

CREATE TABLE `pro_user_otp` (
  `user_otp_id` int UNSIGNED NOT NULL,
  `user_id` int UNSIGNED DEFAULT NULL,
  `mobile_no` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `otp` int UNSIGNED NOT NULL,
  `retry_count` tinyint UNSIGNED NOT NULL,
  `is_active` tinyint UNSIGNED NOT NULL DEFAULT '0' COMMENT '1=> Active',
  `valid_at` timestamp NULL DEFAULT NULL,
  `created_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pro_user_otp`
--

INSERT INTO `pro_user_otp` (`user_otp_id`, `user_id`, `mobile_no`, `otp`, `retry_count`, `is_active`, `valid_at`, `created_by`, `created_at`, `updated_at`, `updated_by`) VALUES
(1, NULL, '2222222222', 123456, 0, 1, '2021-07-04 05:27:48', NULL, '2021-07-04 05:22:48', '2021-07-04 05:22:48', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pro_user_ref`
--

CREATE TABLE `pro_user_ref` (
  `user_ref_id` int UNSIGNED NOT NULL,
  `user_id` int UNSIGNED NOT NULL,
  `ref_name_1` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_mobile_1` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_name_2` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_mobile_2` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pro_user_wf_stage`
--

CREATE TABLE `pro_user_wf_stage` (
  `user_wf_stage_id` int UNSIGNED NOT NULL,
  `wf_stage_id` int UNSIGNED NOT NULL,
  `user_id` int UNSIGNED NOT NULL,
  `is_done` tinyint NOT NULL DEFAULT '0',
  `parent_wf_stage_id` int UNSIGNED NOT NULL,
  `created_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pro_user_wf_stage`
--

INSERT INTO `pro_user_wf_stage` (`user_wf_stage_id`, `wf_stage_id`, `user_id`, `is_done`, `parent_wf_stage_id`, `created_by`, `created_at`, `updated_at`, `updated_by`) VALUES
(1, 1, 1, 0, 0, NULL, NULL, NULL, NULL),
(2, 2, 1, 0, 0, NULL, NULL, NULL, NULL),
(3, 3, 1, 0, 0, NULL, NULL, NULL, NULL),
(4, 4, 1, 0, 0, NULL, NULL, NULL, NULL),
(5, 5, 1, 0, 0, NULL, NULL, NULL, NULL),
(6, 6, 1, 0, 1, NULL, NULL, NULL, NULL),
(7, 7, 1, 0, 1, NULL, NULL, NULL, NULL),
(8, 8, 1, 0, 2, NULL, NULL, NULL, NULL),
(9, 9, 1, 0, 2, NULL, NULL, NULL, NULL),
(10, 10, 1, 0, 2, NULL, NULL, NULL, NULL),
(11, 11, 1, 0, 3, NULL, NULL, NULL, NULL),
(12, 12, 1, 0, 3, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pro_wf_stage`
--

CREATE TABLE `pro_wf_stage` (
  `wf_stage_id` int UNSIGNED NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_doc_required` tinyint NOT NULL DEFAULT '0',
  `parent_wf_stage_id` int UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `created_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pro_wf_stage`
--

INSERT INTO `pro_wf_stage` (`wf_stage_id`, `name`, `is_doc_required`, `parent_wf_stage_id`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1, 'Basic Details', 0, 0, '2021-07-02 18:30:00', NULL, NULL, NULL),
(2, 'KYC', 0, 0, '2021-07-02 18:30:00', NULL, NULL, NULL),
(3, 'Address Details', 0, 0, '2021-07-02 18:30:00', NULL, NULL, NULL),
(4, 'Bank Account Details', 0, 0, '2021-07-02 18:30:00', NULL, NULL, NULL),
(5, 'Reference Contacts', 0, 0, '2021-07-02 18:30:00', NULL, NULL, NULL),
(6, 'Basic Detail 1', 0, 1, '2021-07-02 18:30:00', NULL, NULL, NULL),
(7, 'Basic Detail 2', 0, 1, '2021-07-02 18:30:00', NULL, NULL, NULL),
(8, 'Adhaar', 1, 2, '2021-07-02 18:30:00', NULL, NULL, NULL),
(9, 'PAN', 1, 2, '2021-07-02 18:30:00', NULL, NULL, NULL),
(10, 'Selfie', 1, 2, '2021-07-02 18:30:00', NULL, NULL, NULL),
(11, 'Address Detail 1', 0, 3, '2021-07-02 18:30:00', NULL, NULL, NULL),
(12, 'Address Detail 2', 0, 3, '2021-07-02 18:30:00', NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pro_activity_log`
--
ALTER TABLE `pro_activity_log`
  ADD PRIMARY KEY (`activity_log_id`);

--
-- Indexes for table `pro_api_log`
--
ALTER TABLE `pro_api_log`
  ADD PRIMARY KEY (`api_log_id`);

--
-- Indexes for table `pro_app`
--
ALTER TABLE `pro_app`
  ADD PRIMARY KEY (`app_id`);

--
-- Indexes for table `pro_app_info`
--
ALTER TABLE `pro_app_info`
  ADD PRIMARY KEY (`app_id`);

--
-- Indexes for table `pro_app_status`
--
ALTER TABLE `pro_app_status`
  ADD PRIMARY KEY (`app_status_id`);

--
-- Indexes for table `pro_company`
--
ALTER TABLE `pro_company`
  ADD PRIMARY KEY (`comp_id`);

--
-- Indexes for table `pro_failed_jobs`
--
ALTER TABLE `pro_failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `pro_failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `pro_file`
--
ALTER TABLE `pro_file`
  ADD PRIMARY KEY (`file_id`),
  ADD KEY `created_by` (`created_by`),
  ADD KEY `updated_by` (`updated_by`);

--
-- Indexes for table `pro_migrations`
--
ALTER TABLE `pro_migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pro_mst_activity`
--
ALTER TABLE `pro_mst_activity`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pro_mst_doc`
--
ALTER TABLE `pro_mst_doc`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pro_mst_lang`
--
ALTER TABLE `pro_mst_lang`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pro_mst_sal_mode`
--
ALTER TABLE `pro_mst_sal_mode`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pro_mst_state`
--
ALTER TABLE `pro_mst_state`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pro_mst_status`
--
ALTER TABLE `pro_mst_status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pro_oauth_access_tokens`
--
ALTER TABLE `pro_oauth_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pro_oauth_access_tokens_user_id_index` (`user_id`);

--
-- Indexes for table `pro_oauth_auth_codes`
--
ALTER TABLE `pro_oauth_auth_codes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pro_oauth_auth_codes_user_id_index` (`user_id`);

--
-- Indexes for table `pro_oauth_clients`
--
ALTER TABLE `pro_oauth_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pro_oauth_clients_user_id_index` (`user_id`);

--
-- Indexes for table `pro_oauth_personal_access_clients`
--
ALTER TABLE `pro_oauth_personal_access_clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pro_oauth_refresh_tokens`
--
ALTER TABLE `pro_oauth_refresh_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pro_oauth_refresh_tokens_access_token_id_index` (`access_token_id`);

--
-- Indexes for table `pro_password_resets`
--
ALTER TABLE `pro_password_resets`
  ADD KEY `pro_password_resets_email_index` (`email`);

--
-- Indexes for table `pro_prgm`
--
ALTER TABLE `pro_prgm`
  ADD PRIMARY KEY (`prgm_id`),
  ADD KEY `created_by` (`created_by`),
  ADD KEY `updated_by` (`updated_by`);

--
-- Indexes for table `pro_prgm_wf_stage`
--
ALTER TABLE `pro_prgm_wf_stage`
  ADD PRIMARY KEY (`prgm_wf_stage_id`);

--
-- Indexes for table `pro_user`
--
ALTER TABLE `pro_user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `pro_user_addr`
--
ALTER TABLE `pro_user_addr`
  ADD PRIMARY KEY (`user_addr_id`);

--
-- Indexes for table `pro_user_bank_detail`
--
ALTER TABLE `pro_user_bank_detail`
  ADD PRIMARY KEY (`user_bank_detail_id`);

--
-- Indexes for table `pro_user_consent`
--
ALTER TABLE `pro_user_consent`
  ADD PRIMARY KEY (`user_consent_id`);

--
-- Indexes for table `pro_user_info`
--
ALTER TABLE `pro_user_info`
  ADD PRIMARY KEY (`user_info_id`);

--
-- Indexes for table `pro_user_kyc_doc`
--
ALTER TABLE `pro_user_kyc_doc`
  ADD PRIMARY KEY (`user_kyc_doc_id`);

--
-- Indexes for table `pro_user_otp`
--
ALTER TABLE `pro_user_otp`
  ADD PRIMARY KEY (`user_otp_id`);

--
-- Indexes for table `pro_user_ref`
--
ALTER TABLE `pro_user_ref`
  ADD PRIMARY KEY (`user_ref_id`);

--
-- Indexes for table `pro_user_wf_stage`
--
ALTER TABLE `pro_user_wf_stage`
  ADD PRIMARY KEY (`user_wf_stage_id`);

--
-- Indexes for table `pro_wf_stage`
--
ALTER TABLE `pro_wf_stage`
  ADD PRIMARY KEY (`wf_stage_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pro_activity_log`
--
ALTER TABLE `pro_activity_log`
  MODIFY `activity_log_id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pro_api_log`
--
ALTER TABLE `pro_api_log`
  MODIFY `api_log_id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pro_app`
--
ALTER TABLE `pro_app`
  MODIFY `app_id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pro_app_info`
--
ALTER TABLE `pro_app_info`
  MODIFY `app_id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pro_app_status`
--
ALTER TABLE `pro_app_status`
  MODIFY `app_status_id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pro_company`
--
ALTER TABLE `pro_company`
  MODIFY `comp_id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pro_failed_jobs`
--
ALTER TABLE `pro_failed_jobs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pro_file`
--
ALTER TABLE `pro_file`
  MODIFY `file_id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pro_migrations`
--
ALTER TABLE `pro_migrations`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `pro_mst_activity`
--
ALTER TABLE `pro_mst_activity`
  MODIFY `id` smallint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `pro_mst_doc`
--
ALTER TABLE `pro_mst_doc`
  MODIFY `id` smallint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `pro_mst_lang`
--
ALTER TABLE `pro_mst_lang`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pro_mst_sal_mode`
--
ALTER TABLE `pro_mst_sal_mode`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pro_mst_state`
--
ALTER TABLE `pro_mst_state`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `pro_mst_status`
--
ALTER TABLE `pro_mst_status`
  MODIFY `id` tinyint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT for table `pro_oauth_clients`
--
ALTER TABLE `pro_oauth_clients`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `pro_oauth_personal_access_clients`
--
ALTER TABLE `pro_oauth_personal_access_clients`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pro_prgm`
--
ALTER TABLE `pro_prgm`
  MODIFY `prgm_id` tinyint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `pro_prgm_wf_stage`
--
ALTER TABLE `pro_prgm_wf_stage`
  MODIFY `prgm_wf_stage_id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `pro_user`
--
ALTER TABLE `pro_user`
  MODIFY `user_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `pro_user_addr`
--
ALTER TABLE `pro_user_addr`
  MODIFY `user_addr_id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pro_user_bank_detail`
--
ALTER TABLE `pro_user_bank_detail`
  MODIFY `user_bank_detail_id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pro_user_consent`
--
ALTER TABLE `pro_user_consent`
  MODIFY `user_consent_id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pro_user_info`
--
ALTER TABLE `pro_user_info`
  MODIFY `user_info_id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pro_user_kyc_doc`
--
ALTER TABLE `pro_user_kyc_doc`
  MODIFY `user_kyc_doc_id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pro_user_otp`
--
ALTER TABLE `pro_user_otp`
  MODIFY `user_otp_id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `pro_user_ref`
--
ALTER TABLE `pro_user_ref`
  MODIFY `user_ref_id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pro_user_wf_stage`
--
ALTER TABLE `pro_user_wf_stage`
  MODIFY `user_wf_stage_id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `pro_wf_stage`
--
ALTER TABLE `pro_wf_stage`
  MODIFY `wf_stage_id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
