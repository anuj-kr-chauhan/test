-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 21, 2021 at 08:12 PM
-- Server version: 8.0.21-0ubuntu0.20.04.4
-- PHP Version: 7.3.22-1+ubuntu20.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pro_payday`
--

-- --------------------------------------------------------

--
-- Table structure for table `pro_activity_log`
--

CREATE TABLE `pro_activity_log` (
  `activity_log_id` int UNSIGNED NOT NULL,
  `activity_id` smallint UNSIGNED NOT NULL,
  `activity_desc` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_address` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `route_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int UNSIGNED DEFAULT NULL,
  `app_id` int UNSIGNED DEFAULT NULL,
  `email` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `browser_info` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `device_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` int UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_by` int UNSIGNED NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pro_api_log`
--

CREATE TABLE `pro_api_log` (
  `api_log_id` int UNSIGNED NOT NULL,
  `user_id` int UNSIGNED NOT NULL,
  `doc_id` smallint UNSIGNED NOT NULL,
  `doc_id_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `api_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `req_txt` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `res_txt` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ipaddr` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  `api_url` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_verified` tinyint UNSIGNED NOT NULL COMMENT '1=>verfied,0=> un verified',
  `created_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pro_app`
--

CREATE TABLE `pro_app` (
  `app_id` int UNSIGNED NOT NULL,
  `user_id` int UNSIGNED NOT NULL,
  `is_active` tinyint UNSIGNED NOT NULL DEFAULT '0' COMMENT '1=> Active',
  `app_status_id` smallint UNSIGNED NOT NULL,
  `created_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pro_app_info`
--

CREATE TABLE `pro_app_info` (
  `app_id` int UNSIGNED NOT NULL,
  `user_id` int UNSIGNED NOT NULL,
  `created_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pro_app_status`
--

CREATE TABLE `pro_app_status` (
  `app_status_id` int UNSIGNED NOT NULL,
  `app_id` int UNSIGNED NOT NULL,
  `status_id` smallint UNSIGNED NOT NULL,
  `cmt_txt` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pro_mst_activity`
--

CREATE TABLE `pro_mst_activity` (
  `id` smallint UNSIGNED NOT NULL,
  `route_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `activity_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `activity_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint UNSIGNED NOT NULL,
  `created_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pro_mst_activity`
--

INSERT INTO `pro_mst_activity` (`id`, `route_name`, `activity_code`, `activity_name`, `is_active`, `created_by`, `created_at`) VALUES
(1, '', 'frontend_reg', 'FrontendRegistration', 1, 1, NULL),
(2, '', 'email_verified', 'Email Verified', 1, NULL, NULL),
(3, '', 'mobile_otp_verified', 'mobile_otp_verified', 1, NULL, NULL),
(4, '', 'login', 'Login', 1, NULL, NULL),
(5, '', 'first_time_password_change', 'first_time_password_change', 1, NULL, NULL),
(6, '', 'supplier_form_sbumit', 'supplier_form_sbumit', 1, NULL, NULL),
(7, '', 'change_pwd', 'change_pwd', 1, NULL, NULL),
(8, '', 'forget_pwd', 'forget_pwd', 1, NULL, NULL),
(9, '', 'invpice_upload', 'invpice_upload', 1, NULL, NULL),
(10, '', 'tally_posting', 'tally_posting', 1, NULL, NULL),
(11, '', 'offer_creation', 'offer_creation', 1, NULL, NULL),
(12, '', 'user_limit_enhancement', 'user_limit_enhancement', 1, NULL, NULL),
(13, '', 'user_product_limit_enhancement', 'user_product_limit_enhancement', 1, NULL, NULL),
(14, '', 'Invoice_send_to_disburesement', 'Invoice_send_to_disburesement', 1, NULL, NULL),
(15, '', 'Invoice_Upload_manul_single', 'Invoice_Upload_manul_single', 1, NULL, NULL),
(16, ' ', 'application_renewal', 'Application Renewal', 1, 1, '2020-04-29 18:30:00'),
(17, ' ', 'app_status_changed', 'Application Status Changed', 1, 1, '2020-04-30 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `pro_mst_status`
--

CREATE TABLE `pro_mst_status` (
  `id` tinyint UNSIGNED NOT NULL,
  `status_type` tinyint UNSIGNED NOT NULL COMMENT '1=App Status,2=>User Status,3=>FIRCU Status, 4 - Invoivce status, 5-Agency type',
  `status_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint UNSIGNED NOT NULL DEFAULT '1' COMMENT '1=>Active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pro_mst_status`
--

INSERT INTO `pro_mst_status` (`id`, `status_type`, `status_name`, `is_active`) VALUES
(1, 3, 'Pending', 1),
(2, 3, 'In Progress', 1),
(3, 3, 'Positive', 1),
(4, 3, 'Negative', 1),
(5, 3, 'Cancelled', 1),
(6, 3, 'Refer to credit', 1),
(7, 4, 'Pending', 1),
(8, 4, 'Approved', 1),
(9, 4, 'Disbursment Que', 1),
(10, 4, 'Sent to Bank', 1),
(11, 4, 'Failed Disbursment', 1),
(12, 4, 'Disbursed', 1),
(13, 4, 'Partially Payment Settled ', 1),
(14, 4, 'Reject', 1),
(15, 4, 'Payment Settled', 1),
(16, 5, 'FI', 1),
(17, 5, 'RCU', 1),
(18, 5, 'Inspection', 1),
(19, 1, 'New', 0),
(20, 1, 'Completed', 1),
(21, 1, 'Limit Approved', 1),
(22, 1, 'Offer Accepted', 1),
(23, 1, 'Offer Rejected', 1),
(24, 1, 'Pre Sanction Doc Uploaded', 0),
(25, 1, 'Sanction Letter Generated', 1),
(26, 1, 'Post Sanction Doc Uploaded', 1),
(27, 1, 'Disbursed', 0),
(28, 4, 'Exception Cases', 1),
(30, 6, 'Disburse Pending', 1),
(31, 6, 'Disburse Completed', 1),
(32, 6, 'Disburse Failed', 1),
(33, 7, 'Unsettled', 1),
(34, 7, 'Settled', 1),
(35, 2, 'Account Closure', 1),
(36, 9, 'New', 1),
(37, 9, 'In process', 1),
(38, 9, 'Approved', 1),
(39, 9, 'Transaction Settled', 1),
(40, 9, 'Completed', 1),
(41, 2, 'Write Off', 1),
(42, 9, 'Revert Back', 1),
(43, 1, 'Rejected', 1),
(44, 1, 'Cancelled', 1),
(45, 1, 'On Hold', 1),
(46, 1, 'Data Pending', 1),
(47, 4, 'Settle Po Invoice', 1),
(48, 1, 'NPA', 1),
(49, 1, 'Incomplete', 1),
(50, 1, 'Sanctioned', 1),
(51, 1, 'Closed', 1),
(55, 1, 'Limit Rejected', 1),
(56, 1, 'Offer Generated', 1),
(57, 1, 'Sanction Letter Approved', 1);

-- --------------------------------------------------------

--
-- Table structure for table `pro_user`
--

CREATE TABLE `pro_user` (
  `user_id` int UNSIGNED NOT NULL,
  `comp_id` int UNSIGNED NOT NULL,
  `f_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `m_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `l_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile_no` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_type` tinyint(1) DEFAULT NULL COMMENT '1=>Frontend,2=> Backend',
  `password` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_email_verified` tinyint(1) DEFAULT NULL COMMENT '0=>Not Verified,1 =>Verified',
  `email_verified_updatetime` datetime DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_mobile_verified` tinyint(1) DEFAULT NULL COMMENT '0=>Not Verified,1 =>Verified',
  `otp_verified_updatetime` datetime DEFAULT NULL,
  `is_pwd_changed` tinyint(1) DEFAULT NULL COMMENT '0=>Not Changed, 1=> Changed',
  `pwd_updatetime` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL COMMENT '1=>Active ,0 =>In Active',
  `block_status_id` tinyint DEFAULT NULL,
  `block_status_updatetime` datetime DEFAULT NULL,
  `parent_id` int UNSIGNED DEFAULT NULL,
  `is_assigned` tinyint UNSIGNED NOT NULL DEFAULT '2' COMMENT '1=>Assigned,2=>Not Assigned',
  `created_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pro_user_consent`
--

CREATE TABLE `pro_user_consent` (
  `user_consent_id` int UNSIGNED NOT NULL,
  `user_id` int UNSIGNED NOT NULL,
  `device_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `device_info` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint UNSIGNED NOT NULL DEFAULT '0' COMMENT '1=> Active',
  `created_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pro_user_info`
--

CREATE TABLE `pro_user_info` (
  `user_info_id` int UNSIGNED NOT NULL,
  `user_id` int UNSIGNED NOT NULL,
  `user_dob` date DEFAULT NULL,
  `gender` tinyint UNSIGNED DEFAULT NULL,
  `lang_option` tinyint UNSIGNED NOT NULL,
  `pan_f_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pan_m_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `pan_l_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_married` tinyint UNSIGNED NOT NULL,
  `is_employed` tinyint UNSIGNED NOT NULL,
  `employment_type` tinyint UNSIGNED NOT NULL COMMENT '1-> self employeed,2, Salaried',
  `created_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pro_user_kyc_doc`
--

CREATE TABLE `pro_user_kyc_doc` (
  `kyc_doc_id` int UNSIGNED NOT NULL,
  `user_id` int UNSIGNED NOT NULL,
  `kyc_type` tinyint UNSIGNED NOT NULL COMMENT '1=>Pan,2=>Aadhar,3=>Voter',
  `doc_id` smallint UNSIGNED NOT NULL,
  `kyc_doc_id_no` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lang_option` tinyint UNSIGNED NOT NULL,
  `f_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `m_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `l_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_verified` tinyint UNSIGNED NOT NULL COMMENT '1=>verfied,0=> un verified',
  `verified_auto` tinyint UNSIGNED NOT NULL COMMENT '1=> Autp,2=>manual',
  `api_log_id` int UNSIGNED DEFAULT NULL,
  `is_active` tinyint UNSIGNED NOT NULL DEFAULT '0' COMMENT '1=> Active',
  `created_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pro_user_otp`
--

CREATE TABLE `pro_user_otp` (
  `user_otp_id` int UNSIGNED NOT NULL,
  `user_id` int UNSIGNED NOT NULL,
  `mobile_no` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `otp` int UNSIGNED NOT NULL,
  `retery_count` tinyint UNSIGNED NOT NULL,
  `is_active` tinyint UNSIGNED NOT NULL DEFAULT '0' COMMENT '1=> Active',
  `vatid_at` timestamp NOT NULL,
  `created_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int UNSIGNED DEFAULT NULL COMMENT 'Foreign key of table Users'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pro_mst_activity`
--
ALTER TABLE `pro_mst_activity`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pro_mst_status`
--
ALTER TABLE `pro_mst_status`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pro_mst_status`
--
ALTER TABLE `pro_mst_status`
  MODIFY `id` tinyint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
