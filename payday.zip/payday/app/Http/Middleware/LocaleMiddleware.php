<?php

namespace App\Http\Middleware;

use Illuminate\Http\Request;
use Closure;
use App;

class LocaleMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        $locale = $request->header('locale') ?? 'en';
        $lang_array = config('setting.lang_array') ?? ['en'];
        $old_locale = App::getLocale();
        if(in_array($locale, $lang_array) && $old_locale != $locale){
            App::setLocale($locale);
        }elseif(!in_array($locale, $lang_array)){
            App::setLocale('en');
        }
        return $next($request);
    }
}
