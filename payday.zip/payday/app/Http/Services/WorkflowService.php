<?php
namespace App\Http\Services;

use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use App\Models\ProgramWfStage;
use App\Models\UserWfStage;
use App\Models\WfStage;
use Carbon\Carbon;
use Helper;

class WorkflowService
{
    public function addUserWfStage($user_id, $prgm_id){
        $wf_stages = ProgramWfStage::where('prgm_id', $prgm_id)->pluck('wf_stage_id');
        $child_wf_stages = WfStage::whereIn('parent_wf_stage_id', $wf_stages)->pluck('parent_wf_stage_id', 'wf_stage_id');
        $data=[];
        foreach($wf_stages as $key=>$value){
            $arr = [
                'wf_stage_id' => $value,
                'parent_wf_stage_id' => 0,
                'user_id' => $user_id,
                'created_at' => Carbon::now(),
                'created_by' => $user_id,
            ];
            array_push($data, $arr);
        }

        foreach($child_wf_stages as $key=>$value){
            $arr = [
                'wf_stage_id' => $key,
                'parent_wf_stage_id' => $value,
                'user_id' => $user_id,
                'created_at' => Carbon::now(),
                'created_by' => $user_id,
            ];
            array_push($data, $arr);
        }

        $status = UserWfStage::insert($data);
        return $status;
    }

    public function updateUserWfStage($user_id, $wf_stage_id, $child_wf_stage_id=null){
        if($child_wf_stage_id){
            $child_wf_stage_done = UserWfStage::where(['user_id'=> $user_id, 'wf_stage_id'=> $child_wf_stage_id, 'parent_wf_stage_id'=> $wf_stage_id])->update(['is_done'=> 1]);
            return true;
        }else{
            $wf_status = UserWfStage::where(['user_id'=> $user_id, 'parent_wf_stage_id'=> $wf_stage_id, 'is_done'=> 0])->count();
            if($wf_status == 0){
                $wf_stage_done = UserWfStage::where(['user_id'=> $user_id, 'wf_stage_id'=> $wf_stage_id, 'parent_wf_stage_id'=> 0])->update(['is_done'=> 1]);
                return true;
            }else{
                return false;
            }
        }
    }

    // Function return the current wf stage and all wf stages list
    public function getUserWfStage($user_id){
        $user_wf_stages = UserWfStage::where(['user_id'=> $user_id, 'parent_wf_stage_id'=> 0])->get();
        $wf_stage_id = 0;
        //$wf_step_id = 0;
        $wf_stages = [];
        //$wf_steps = [];
        $is_skip = 1;
        foreach ($user_wf_stages as $key => $stage) {
            if($stage->is_done == 0 && $is_skip){
                $is_skip = 0;
                $k = $key+1;
                array_push($wf_stages, ["step_key"=> "step$k", "step_id"=> $stage->wf_stage_id]);
                $wf_stage_id = $stage->wf_stage_id;
                // array_push($wf_stages, $stage->wf_stage_id);
                // $wf_step_id = "step$k";
            }else{
                $k = $key+1;
                array_push($wf_stages, ["step_key"=> "step$k", "step_id"=> $stage->wf_stage_id]);
                //array_push($wf_stages, $stage->wf_stage_id);
                //array_push($wf_steps, ["step$k"=> $stage->wf_stage_id]);
            }
        }
        return ['wf_stages'=> $wf_stages, 'wf_stage_id'=> $wf_stage_id];
    }

    // If function return true then update the wf stage
    public function checkUserWfStage($user_id, $wf_stage_id){
        $user_wf_stages = UserWfStage::where(['user_id'=> $user_id, 'parent_wf_stage_id'=> 0])->get();
        $status = false;
        foreach ($user_wf_stages as $key => $stage) {
            if($stage->is_done == 0){
                $status = ($stage->wf_stage_id == $wf_stage_id) ? true : false;
                break;
            }else{
                $status = false;
            }
        }
        return $status;
    }

    // Function return true if child wf stage complete
    public function isFinalWfStage($user_id, $wf_stage_id){
        $user_wf_stage = UserWfStage::where(['user_id'=> $user_id, 'wf_stage_id'=> $wf_stage_id, 'is_done'=> 1])->count();
        $user_wf_child_stage = UserWfStage::where(['user_id'=> $user_id, 'parent_wf_stage_id'=> $wf_stage_id])->pluck('is_done')->toArray();
        
        if($user_wf_stage){
            return false;
        }elseif(count($user_wf_child_stage) == 0){
            return false;
        }elseif(in_array(0, $user_wf_child_stage)){
            return false;
        }else{
            return true;
        }
    }

    // dd($this->wf_service->updateUserWfStage(5, 1));
    // dd($this->wf_service->updateUserWfStage(5, 1, 6));
    // dd($this->wf_service->checkUserWfStage(5, 1));
    // dd($this->wf_service->getUserWfStage(5));
}

