<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use App\Http\Services\WorkflowService;
use Illuminate\Http\Request;
use App\Models\UserOtp;
use App\Models\User;
use Carbon\Carbon;
use Helper;
use Hash;

class AuthController extends Controller
{
    protected $wf_service; 

    public function __construct(){
        $this->wf_service = new WorkflowService();
    }

    public function loginWithOTP(Request $request){
        try{
            $validator = Validator::make($request->all(), [
                'mobile_no' => 'required|digits:10|regex:/[1-9]{1}\d{9}/',
                //'email' => 'required|email|unique:user',
                'otp' => 'required|digits:6',
            ]);
            if ($validator->fails()) {
                return Helper::sendResponse(0, $validator->errors()->first(), 200);
            }

            $otp_expiry_time = config('setting.otp_expiry_time', 5);
            $user = User::where(['mobile_no'=>$request->mobile_no, 'is_active'=> 1])->first();
            $user_otp = UserOtp::where(['mobile_no'=>$request->mobile_no, 'otp'=>$request->otp, 'is_active'=>1])->latest()->first();
            if($user == null){
                return Helper::sendResponse(0, __('common.user_not_found'), 200);
            }elseif($user && $user_otp && Carbon::createFromFormat('Y-m-d H:i:s', $user_otp->created_at)->gt(Carbon::now()->addMinutes(-$otp_expiry_time))){
                $user_otp->update(['is_active'=>0]);
                $token = $user->createToken('appToken')->accessToken;
                $temp_token = Helper::getRandomString();
                $user->temp_token = $temp_token;
                $user->temp_token_updatetime = Carbon::now();
                $user->save();
                return Helper::sendResponse(1, __('common.token_create_success'), 200, ['token' => $token, 'temp_token' => $temp_token]);
            }else{
                return Helper::sendResponse(0, 'OTP expired/mismatch, Please resend OTP and verify again', 200);
            }
        }catch(\Exception $e){
            return Helper::sendResponse(0, __('common.something_went_wrong'), 500);
        }
    }

    public function loginWithPassword(Request $request){
        try{
            $validator = Validator::make($request->all(), [
                'mobile_no' => 'required|digits:10|regex:/[2-9]{1}\d{9}/',
                //'email' => 'required|email|unique:user',
                'password' => 'required|min:6|max:25',
            ]);
            if ($validator->fails()) {
                return Helper::sendResponse(0, $validator->errors()->first(), 200);
            }

            $user = User::where(['mobile_no'=> $request->mobile_no, 'is_active'=> 1])->first();
            if($user && Hash::check($request->password, $user->password)){
                //Auth::loginUsingId($user->user_id);
                $token = $user->createToken('appToken')->accessToken;
                $temp_token = Helper::getRandomString();
                $user->temp_token = $temp_token;
                $user->temp_token_updatetime = Carbon::now();
                $user->save();
                return Helper::sendResponse(1, __('common.token_create_success'), 200, ['token' => $token, 'temp_token' => $temp_token]);
            }else{
                return Helper::sendResponse(0, __('common.invalid_mob_pass'), 200);
            }
        }catch(\Exception $e){
            return Helper::sendResponse(0, __('common.something_went_wrong'), 500);
        }
    }

    /**
     * Register api.
     *
     * @return \Illuminate\Http\Response
     */
    public function register(Request $request){
        try{
            $validator = Validator::make($request->all(), [
                'otp' => 'required|digits:6',
                'mobile_no' => 'required|unique:user|digits:10|regex:/[2-9]{1}\d{9}/',
                //'email' => 'required|email|unique:user',
                'password' => 'required|min:6|max:25',
            ]);
            if ($validator->fails()) {
                return Helper::sendResponse(0, $validator->errors()->first(), 200);
            }
            $data['mobile_no'] = $request->mobile_no;
            $data['password'] = bcrypt($request->password);

            $otp_expiry_time = config('setting.otp_expiry_time', 5);
            $user_otp = UserOtp::where(['mobile_no'=>$request->mobile_no, 'otp'=>$request->otp, 'is_active'=>1])->latest()->first();
            if($user_otp && Carbon::createFromFormat('Y-m-d H:i:s', $user_otp->created_at)->gt(Carbon::now()->addMinutes(-$otp_expiry_time))){
                $temp_token = Helper::getRandomString();
                $user = User::create(array_merge($data, ['temp_token' => $temp_token, 'temp_token_updatetime' => Carbon::now()]));
                $user_otp->update(['is_active'=>0]);
                $token = $user->createToken('appToken')->accessToken;
                // Add wf stage to the user_wf_stage table
                $prgm_id = config('setting.prgm_id', 1);
                $this->wf_service->addUserWfStage($user->user_id, $prgm_id);
                return Helper::sendResponse(1, __('common.user_create_success'), 200, ['token' => $token, 'temp_token' => $temp_token]);
            }else{
                return Helper::sendResponse(0, 'OTP expired/mismatch, Please resend OTP and verify again', 200);
            }
        }catch(\Exception $e){
            return Helper::sendResponse(0, __('common.something_went_wrong'), 500);
        }
    }

    public function logout(Request $request){
        try{
            if ($request->user()) {
                $user_id = $request->user()->user_id;
                User::where('user_id', $user_id)->update(['temp_token' => null, 'temp_token_updatetime' => null]);
                $user = $request->user()->token();
                $user->revoke();
                return Helper::sendResponse(1, __('common.logout'), 200);
            }else {
                return Helper::sendResponse(1, __('common.already_logout'), 200);
            }
        }catch(\Exception $e){
            return Helper::sendResponse(0, __('common.something_went_wrong'), 500);
        }
    }

    public function sendOTP(Request $request){
        try{
            $validator = Validator::make($request->all(), [
                'mobile_no' => 'required|digits:10|regex:/[1-9]{1}\d{9}/',
            ]);
            if ($validator->fails()) {
                return Helper::sendResponse(0, $validator->errors()->first(), 200);
            }
            $otp_expiry_time = config('setting.otp_expiry_time', 5);
            $otp_retry_time = config('setting.otp_retry_time', 60);
            $otp_attempt = config('setting.otp_attempt', 3);
            $from_date = Carbon::now()->addMinutes(-$otp_retry_time);
            $to_date = Carbon::now();
            $user = User::where(['mobile_no'=>$request->mobile_no, 'is_active'=> 1])->first();
            $user_id = $user ? $user->user_id : null;
            
            $user_otp = UserOtp::where(['mobile_no'=>$request->mobile_no])->whereBetween('created_at', [$from_date, $to_date])->count();

            if($user_otp == $otp_attempt){
                return Helper::sendResponse(0, 'your attempts expire, please try after 1 hour', 200);
            }else{
                UserOtp::where(['mobile_no'=>$request->mobile_no, 'is_active'=> 1])->update(['is_active'=> 0]);
                UserOtp::create(['user_id'=>$user_id, 'mobile_no'=>$request->mobile_no, 'otp'=>'123456', 'retry_count'=>0, 'is_active'=> 1, 'valid_at'=> Carbon::now()->addMinute($otp_expiry_time), 'created_by'=> $user_id]);
                return Helper::sendResponse(1, __('common.otp_send_success'), 200);
            }
        }catch(\Exception $e){
            return Helper::sendResponse(0, __('common.something_went_wrong'), 500);
        }
    }

    public function verifyOTP(Request $request){
        try{
            $validator = Validator::make($request->all(), [
                'mobile_no' => 'required|digits:10|regex:/[1-9]{1}\d{9}/',
                'otp' => 'required|digits:6',
            ]);
            if ($validator->fails()) {
                return Helper::sendResponse(0, $validator->errors()->first(), 200);
            }
            $otp_expiry_time = config('setting.otp_expiry_time', 5);
            $otp_retry_time = config('setting.otp_retry_time', 60);
            $otp_attempt = config('setting.otp_attempt', 3);
            $from_date = Carbon::now()->addMinutes(-$otp_retry_time);
            $to_date = Carbon::now();
            $user = User::where(['mobile_no'=>$request->mobile_no, 'is_active'=> 1])->first();
            $user_id = $user ? $user->user_id : null;
            
            $user_otp = UserOtp::where(['mobile_no'=>$request->mobile_no, 'is_active'=>1])->latest()->first();

            if($user_otp && $user_otp->retry_count == $otp_attempt){
                return Helper::sendResponse(0, 'Your attempts expire, please try after 1 hour', 200);
            }elseif($user_otp && Carbon::createFromFormat('Y-m-d H:i:s', $user_otp->valid_at)->lt(Carbon::now())){
                return Helper::sendResponse(0, 'OTP expired, please resend OTP', 200);
            }elseif($user_otp && $user_otp->otp != $request->otp){
                $user_otp->update(['retry_count'=> $user_otp->retry_count+1]);
                return Helper::sendResponse(0, 'OTP not match, please enter correct OTP', 200);
            }elseif($user_otp && $user_otp->otp == $request->otp){
                //$user_otp->update(['is_active'=> 0]);
                return Helper::sendResponse(1, 'OTP matched successfully', 200);
            }else{
                return Helper::sendResponse(0, 'Please resend OTP and then try', 200);
            }
        }catch(\Exception $e){
            return Helper::sendResponse(0, __('common.something_went_wrong'), 500);
        }
    }

    public function refreshToken(Request $request){
        try{
            $validator = Validator::make($request->all(), [
                'temp_token' => 'required|max:100'
            ]);
            if ($validator->fails()) {
                return Helper::sendResponse(0, $validator->errors()->first(), 200);
            }

            $temp_token_expiry_time = config('setting.temp_token_expiry_time', 15);
            $user = User::where(['temp_token' => $request->temp_token, 'is_active' => 1])->first();
            if($user && Carbon::createFromFormat('Y-m-d H:i:s', $user->temp_token_updatetime)->gt(Carbon::now()->addMinutes(-$temp_token_expiry_time))){
                $user_id = $user->user_id;

                if($request->user()){
                    $old_user = $request->user()->token();
                    $old_user->revoke();
                }

                $user2 = User::find($user_id)->first();
                $token = $user2->createToken('appToken')->accessToken;
                $temp_token = Helper::getRandomString();
                $user2->temp_token = $temp_token;
                $user2->temp_token_updatetime = Carbon::now();
                $user2->save();
                return Helper::sendResponse(1, __('common.token_ref_success'), 200, ['token' => $token, 'temp_token' => $temp_token]);
            }else{
                return Helper::sendResponse(0, 'Please contact to Administrator', 200);
            }
        }catch(\Exception $e){
            return Helper::sendResponse(0, __('common.something_went_wrong'), 500);
        }
    }

    public function refreshTokenOld(Request $request){
        try{
            if($request->user()){
                $user_id = $request->user()->user_id;
                $user = $request->user()->token();
                $user->revoke();

                $user2 = User::find($user_id)->first();
                //Auth::loginUsingId(1);
                $token = $user2->createToken('appToken')->accessToken;
                return Helper::sendResponse(1, __('common.token_ref_success'), 200, ['token' => $token]);
            }else{
                return Helper::sendResponse(0, __('common.login_again'), 200);

            }
        }catch(\Exception $e){
            return Helper::sendResponse(0, __('common.something_went_wrong'), 500);
        }
    }

    public function changePassword(Request $request){
        try{
            $validator = Validator::make($request->all(), [
                'old_password' => 'required|min:6|max:25',
                'new_password' => 'required|min:6|max:25'
            ]);
            if ($validator->fails()) {
                return Helper::sendResponse(0, $validator->errors()->first(), 200);
            }

            $user = $request->user();

            if($user && Hash::check($request->old_password, $user->password)){
                $password = Hash::make($request->password);
                $user->update(['password'=> $password, 'is_pwd_changed'=>'1', 'pwd_updatetime' => Carbon::now()]);
                return Helper::sendResponse(1, __('common.password_upd_success'), 200);
            }elseif($user){
                return Helper::sendResponse(0, __('common.password_not_match'), 200);
            }else{
                return Helper::sendResponse(0, __('common.login_first'), 200);

            }
        }catch(\Exception $e){
            return Helper::sendResponse(0, __('common.something_went_wrong'), 500);
        }
    }

    public function forgotPassword(Request $request){
        try{
            $validator = Validator::make($request->all(), [
                'otp' => 'required|digits:6',
                'mobile_no' => 'required|digits:10|regex:/[1-9]{1}\d{9}/',
                'new_password' => 'required|min:6|max:25'
            ]);
            if ($validator->fails()) {
                return Helper::sendResponse(0, $validator->errors()->first(), 200);
            }

            $otp_expiry_time = config('setting.otp_expiry_time', 5);
            $user = User::where(['mobile_no'=>$request->mobile_no, 'is_active'=> 1]);
            $user_otp = UserOtp::where(['mobile_no'=>$request->mobile_no, 'otp'=>$request->otp, 'is_active'=>1])->latest()->first();
            if($user && $user_otp && Carbon::createFromFormat('Y-m-d H:i:s', $user_otp->created_at)->gt(Carbon::now()->addMinutes(-$otp_retry_time))){
                $user_otp->update(['is_active'=>0]);
                $password = Hash::make($request->new_password);
                $user->update(['password'=> $password, 'is_pwd_changed'=>'1', 'pwd_updatetime' => Carbon::now()]);
                return Helper::sendResponse(1, __('common.password_upd_success'), 200);
            }else{
                return Helper::sendResponse(0, 'OTP expired/mismatch, Please resend OTP and verify again', 200);
            }
        }catch(\Exception $e){
            return Helper::sendResponse(0, __('common.something_went_wrong'), 500);
        }
    }

}
