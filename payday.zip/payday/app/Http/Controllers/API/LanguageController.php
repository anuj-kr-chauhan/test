<?php
namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use App\Models\MstLanguage;
use Helper;

class LanguageController extends Controller
{
    public function getLanguages()
    {
        try
        {
            $languages = MstLanguage::where('is_active', 1)->get();
            return Helper::sendResponse(1, __('common.get_lang_success'), 200, $languages);
        }
        catch(\Exception $e)
        {
            return Helper::sendResponse(0, __('common.something_went_wrong'), 500);
        }
    }
}

