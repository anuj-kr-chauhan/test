<?php
namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use App\Models\MstSalaryMode;
use Helper;

class SalaryController extends Controller
{
    public function getSalaryMode()
    {
        try
        {
            $modes = MstSalaryMode::where('is_active', 1)->get();
            return Helper::sendResponse(1, __('common.get_sal_mode_success'), 200, $modes);
        }
        catch(\Exception $e)
        {
            return Helper::sendResponse(0, __('common.something_went_wrong'), 500);
        }
    }
}

