<?php
namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use App\Models\MstState;
use Helper;

class StateController extends Controller
{
    public function getStates(Request $request)
    {
        try
        {
            $validator = Validator::make($request->all() , [
                'country_id' => 'nullable|numeric',
            ]);
            if ($validator->fails()){
                return Helper::sendResponse(0, $validator->errors()->first() , 200);
            }

            $states = MstState::where('is_active', 1)->get(['id','name']);
            return Helper::sendResponse(1, __('common.get_all_states_success'), 200, $states);
        }
        catch(\Exception $e)
        {
            return Helper::sendResponse(0, __('common.something_went_wrong'), 500);
        }
    }


}

