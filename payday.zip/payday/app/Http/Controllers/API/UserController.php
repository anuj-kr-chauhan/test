<?php
namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\MstCompany;  
use App\Models\UserInfo;
use App\Models\UserKycDoc;
use App\Models\UserAddress;
use App\Models\UserWfStage;
use App\Models\UserReference;
use App\Models\UserBankDetail;
use App\Http\Services\WorkflowService;
use Carbon\Carbon;
use Helper;

class UserController extends Controller
{
    protected $wf_service; 

    public function __construct(){
        $this->wf_service = new WorkflowService();
    }

    public function getUser(Request $request){
        try{
            $user = $request->user()->load('userInfo','userAddress.state','company');
            // $activity_log = Helper::activityLog(['activity_id'=>1, 'activity_desc'=>'hghgfg', 'ip_address'=>'123.23.23.234', 'route_name'=>'hhfghfg', 'browser_info'=>'ghfgfgdf', 'source'=> 'hfghfgff', 'device_type'=> 'hhgfgfgdfg']);
            // $api_log = Helper::apiLog(['user_id'=> 1, 'doc_id'=> 1, 'doc_id_no'=> 'gfgfdff', 'api_name'=> 'gfgfdff', 'req_txt'=> 'gfgfdff', 'res_txt'=> 'gfgfdff', 'ipaddr'=> '123.34.34.123', 'api_url'=> 'gfgfdff', 'is_verified'=> 1]);
            return Helper::sendResponse(1, __('common.user_get_success'), 200, $user);
        }catch(\Exception $e){
            return Helper::sendResponse(0, __('common.something_went_wrong'), 500);
        }
    }

    public function uploadFile(Request $request){
        try{
            $validator = Validator::make($request->all() , [
                'image' => 'required|mimes:jpeg,jpg,png|required|max:5120'
            ]);
            if ($validator->fails()){
                return Helper::sendResponse(0, $validator->errors()->first() , 200);
            }

            $file_data = Helper::uploadImage($request->image, $request->user()->user_id, 0);
            if($file_data){
                return Helper::sendResponse(1, __('common.image_upload_success'), 200, $file_data);
            }else{
                return Helper::sendResponse(0, __('common.image_not_upload'), 200);
            }
        }catch(\Exception $e){
            return Helper::sendResponse(0, __('common.something_went_wrong'), 500);
        }
    }

    public function uploadAdhaar(Request $request){
        try{
            $validator = Validator::make($request->all() , [
                    'adhaar_front' => 'required|mimes:jpeg,jpg,png|required|max:5120', 
                    'adhaar_back' => 'required|mimes:jpeg,jpg,png|required|max:5120', 
                    'adhaar_no' => 'required|digits:12', 
                ]);
            if ($validator->fails()){
                return Helper::sendResponse(0, $validator->errors()->first() , 200);
            }
            $user_id = $request->user()->user_id;
            $wf_status = $this->wf_service->checkUserWfStage($user_id, 2);
            if($wf_status){
                $file_data1 = Helper::uploadImage($request->adhaar_front, $user_id, 0);
                $file_data2 = Helper::uploadImage($request->adhaar_back, $user_id, 0);
                if($file_data1 && $file_data2){
                    //insert into kyc table
                    $user_kyc_doc_count=UserKycDoc::where(['user_id'=> $user_id, 'is_active'=>1])
                        ->whereIn('mst_doc_id', [1,2])->count();
                    if ($user_kyc_doc_count == 0){
                        UserKycDoc::insert([
                        ['user_id'=> $user_id, 'file_id'=> $file_data1->file_id, 'mst_doc_id'=>1, 'doc_no'=> $request->adhaar_no, 'is_active'=>1, 'created_by'=> $user_id,'created_at'=>Carbon::now(),'user_id'=> $user_id],
                        ['user_id'=> $user_id, 'file_id'=> $file_data2->file_id, 'mst_doc_id'=>2, 'doc_no'=> $request->adhaar_no, 'is_active'=>1, 'created_by'=> $user_id,'created_at'=>Carbon::now(),'user_id'=> $user_id]
                        ]);
                    }else{
                        UserKycDoc::where(['user_id'=> $user_id, 'is_active'=>1, 'mst_doc_id'=> 1])
                            ->update(['file_id'=> $file_data1->file_id, 'doc_no'=> $request->adhaar_no, 'updated_by'=> $user_id]);
                        UserKycDoc::where(['user_id'=> $user_id, 'is_active'=>1, 'mst_doc_id'=> 2])
                            ->update(['file_id'=> $file_data2->file_id, 'doc_no'=> $request->adhaar_no, 'updated_by'=> $user_id]);
                    }
                    $this->wf_service->updateUserWfStage($user_id, 2, 8);
                    return Helper::sendResponse(1, 'Adhaar uploaded successfully', 200);
                }else{
                    return Helper::sendResponse(0, 'Adhaar not uploaded, Try again', 200);
                }
            }else{
                return Helper::sendResponse(0, 'Oops! You are on wrong workflow stage', 200);
            }
        }catch(\Exception $e){
            return Helper::sendResponse(0, __('common.something_went_wrong'), 500);
        }
    }

    public function uploadPan(Request $request){
        try{
            $validator = Validator::make($request->all() , [
                    'pan_front' => 'required|mimes:jpeg,jpg,png|required|max:5120', 
                    'pan_no' => 'required|min:10|max:10|regex:/^[\w]{10}/', 
                ]);
            if ($validator->fails()){
                return Helper::sendResponse(0, $validator->errors()->first() , 200);
            }
            $user_id = $request->user()->user_id;
            $wf_status = $this->wf_service->checkUserWfStage($user_id, 2);
            if($wf_status){
                $file_data = Helper::uploadImage($request->pan_front, $user_id, 0);
                if($file_data){
                    //insert into kyc table
                    $user_kyc_doc_count=UserKycDoc::where(['user_id'=> $user_id, 'is_active'=>1])
                        ->whereIn('mst_doc_id', [3])->count();
                    if ($user_kyc_doc_count == 0){
                        UserKycDoc::insert([
                            ['user_id'=> $user_id, 'file_id'=> $file_data->file_id, 'mst_doc_id'=>3, 'doc_no'=> $request->pan_no, 'is_active'=>1, 'created_by'=> $user_id,'created_at'=>Carbon::now(),'user_id'=> $user_id],
                            ]);
                    }else{
                        UserKycDoc::where(['user_id'=> $user_id, 'is_active'=>1, 'mst_doc_id'=> 3])
                            ->update(['file_id'=> $file_data->file_id, 'doc_no'=> $request->pan_no, 'updated_by'=> $user_id]);
                    }
                    $this->wf_service->updateUserWfStage($user_id, 2, 9);
                    return Helper::sendResponse(1, 'PAN uploaded successfully', 200, $file_data);
                }else{
                    return Helper::sendResponse(0, 'PAN not uploaded, Try again', 200);
                }
            }else{
                return Helper::sendResponse(0, 'Oops! You are on wrong workflow stage', 200);
            }
        }catch(\Exception $e){
            return Helper::sendResponse(0, __('common.something_went_wrong'), 500);
        }
    }
    
    public function uploadSelfie(Request $request){
        try{
            $validator = Validator::make($request->all() , [
                    'selfie_image' => 'required|mimes:jpeg,jpg,png|required|max:5120',
                ]);
            if ($validator->fails()){
                return Helper::sendResponse(0, $validator->errors()->first() , 200);
            }
            $user_id = $request->user()->user_id;
            $wf_status = $this->wf_service->checkUserWfStage($user_id, 2);
            if($wf_status){
                $file_data = Helper::uploadImage($request->selfie_image, $user_id, 0);
                if($file_data){
                    //insert into kyc table
                    $user_kyc_doc_count=UserKycDoc::where(['user_id'=> $user_id, 'is_active'=>1])
                        ->whereIn('mst_doc_id', [4])->count();
                    if ($user_kyc_doc_count == 0){
                        UserKycDoc::insert([
                            ['user_id'=> $user_id, 'file_id'=> $file_data->file_id, 'mst_doc_id'=>4, 'is_active'=>1, 'created_by'=> $user_id, 'created_at'=>Carbon::now()]
                            ]);
                    }else{
                        UserKycDoc::where(['user_id'=> $user_id, 'is_active'=>1, 'mst_doc_id'=> 4])
                            ->update(['file_id'=> $file_data->file_id, 'updated_by'=> $user_id]);
                    }
                    $this->wf_service->updateUserWfStage($user_id, 2, 10);
                    return Helper::sendResponse(1, 'Selfie uploaded successfully', 200, $file_data);
                }else{
                    return Helper::sendResponse(0, 'Selfie not uploaded, Try again', 200);
                }
            }else{
                return Helper::sendResponse(0, 'Oops! You are on wrong workflow stage', 200);
            }
        }catch(\Exception $e){
            return Helper::sendResponse(0, __('common.something_went_wrong'), 500);
        }
    }
    
    public function updateBasicDetail(Request $request){
        try{
            $validator = Validator::make($request->all() , [
                    'f_name' => 'required|min:3|max:25|regex:/^[\pL\s]+$/u',
                    'l_name' => 'required|min:3|max:25|regex:/^[\pL\s]+$/u',
                    'email'=>'required|email|min:6|Max:50',
                    'user_dob' => 'required|date_format:Y-m-d',
                    'gender' => 'required|in:1,2',
                ]);

            $data1 = ['f_name' => $request->f_name, 'l_name' => $request->l_name, 'email'=>$request->email];
            $data2 = ['user_dob' => $request->user_dob, 'gender' => $request->gender];

            if ($validator->fails()){
                return Helper::sendResponse(0, $validator->errors()->first() , 200);
            }

            $user_id = $request->user()->user_id;
            $wf_status = $this->wf_service->checkUserWfStage($user_id, 1);
            if($wf_status){
                $user = User::where('user_id', $user_id)->update($data1);
                $user_info = UserInfo::where('user_id', $user_id)->first();

                if (is_null($user_info)){
                    $uid = array('user_id' => $user_id, 'created_by'=> $user_id);
                    $data2 = array_merge($data2, $uid);
                    UserInfo::create($data2);
                }else{
                    $uid = array('updated_by'=> $user_id);
                    $data2 = array_merge($data2, $uid);
                    $user_info->update($data2);
                }
                
                $this->wf_service->updateUserWfStage($user_id, 1, 6);
                return Helper::sendResponse(1, 'Basic detail updated successfully', 200, array_merge($data1, $data2));
            }else{
                return Helper::sendResponse(0, 'Oops! You are on wrong workflow stage', 200);
            }
        }catch(\Exception $e){
            return Helper::sendResponse(0, __('common.something_went_wrong'), 500);
        }
    }

    public function updateEmployeementDetail(Request $request){
        try{
            if($request->employment_type==1){ //1 = Salaried
                $validator = Validator::make($request->all() , [ 
                    'mode_of_salary' => 'required|in:1,2,3',
                    'employment_type' => 'required|in:1,2',
                    'monthly_salary' => 'required|digits_between:4,10|numeric',
                    'comp_id' => 'required|digits_between:1,10|numeric',
                    'comp_name'=>'nullable|min:4|max:100',
                ]);
                $data = [ 'mode_of_salary' => $request->mode_of_salary, 'employment_type' => $request->employment_type, 'monthly_salary' => $request->monthly_salary,'monthly_income' => 0];

                if($request->comp_id == 0){
                    $company = MstCompany::where(['name' => $request->comp_name])->first();
                    if($company){
                        $data2['comp_id'] = $company->comp_id;
                    }else{
                        $new_company = MstCompany::insert(['name' => $request->comp_name,'created_at'=>Carbon::now()]);
                        $data2['comp_id'] = $new_company->comp_id;
                    }
                }else{
                    $company = MstCompany::where(['comp_id' => $request->comp_id])->first();
                    if($company){
                        $data2['comp_id'] =  $company->comp_id;
                    }else{
                        return Helper::sendResponse(0, 'You have selected company out of the list' , 200);
                    }  
                } 
            }else{ // 2 = Self employeed
                $validator = Validator::make($request->all() , [
                    'employment_type' => 'required|in:1,2',
                    'monthly_income' => 'required|digits_between:4,10|numeric'
                ]);

                $data = [ 'mode_of_salary' => "0", 'employment_type' => $request->employment_type, 'monthly_salary' => "0",'monthly_income' => $request->monthly_income ];
                $data2 = ['comp_id' => "0"];
            }
            
            if ($validator->fails()){
                return Helper::sendResponse(0, $validator->errors()->first() , 200);
            }

            $user_id = $request->user()->user_id;
            $wf_status = $this->wf_service->checkUserWfStage($user_id, 1);
            if($wf_status){
                $user_info = UserInfo::where('user_id', $user_id)->first();
                if (is_null($user_info)){
                    $uid = array('user_id' => $user_id, 'created_by'=> $user_id,'created_at'=>Carbon::now());
                    $data = array_merge($data, $uid);
                    UserInfo::insert($data);
                }else{
                    $uid = array('updated_by'=> $user_id );
                    $data = array_merge($data, $uid);
                    $u=UserInfo::where('user_id', $user_id)->update($data);
                }
                User::where('user_id', $user_id)->update($data2);
                $this->wf_service->updateUserWfStage($user_id, 1, 7);
                return Helper::sendResponse(1, 'Employeement detail updated successfully', 200, $data);
            }else{
                return Helper::sendResponse(0, 'Oops! You are on wrong workflow stage', 200);
            }
        }catch(\Exception $e){
            return Helper::sendResponse(0, __('common.something_went_wrong'), 500);
        }
    }
    
    public function updateAddressDetail(Request $request){        
        try{
            $user_id = $request->user()->user_id;
            $validator = Validator::make($request->all() , [
                'addr1' => 'required|min:10|max:100',
                'addr2' => 'required|min:10|max:100', 
                'city' => 'required|min:3|max:40|regex:/^[\pL\s]+$/u',
                'state_id' => 'required|digits_between:1,10|numeric', 
                'pincode' => 'required|digits:6',
                'addr_type' => 'required|in:1,2'
            ]);

            $data = [
                'user_id' => $user_id,
                'addr1' => $request->addr1, 
                'addr2' => $request->addr2, 
                'city' => $request->city,
                'state_id' => $request->state_id, 
                'pincode' => $request->pincode, 
                'is_addr_same' => $request->has('is_addr_same') && $request->is_addr_same == 1 ? 1: 0, 
                'addr_type' => $request->addr_type
            ];

            if ($validator->fails()){
                return Helper::sendResponse(0, $validator->errors()->first() , 200);
            }

            $wf_status = $this->wf_service->checkUserWfStage($user_id, 3);
            if($wf_status){
                if($request->addr_type == 1 && $request->has('is_addr_same') && $request->is_addr_same == 1){
                    // for permanent address
                    $per_address = UserAddress::where(['user_id'=> $user_id, 'addr_type'=> 1])->first();
                    if($per_address){
                        $uid = array('updated_by'=> $user_id );
                        $data = array_merge($data, $uid);
                        $per_address->update($data);
                    }else{
                        $uid = array('created_by'=> $user_id );
                        $data = array_merge($data, $uid);
                        UserAddress::create($data);
                    }
                    $this->wf_service->updateUserWfStage($user_id, 3, 11);
                    // for correspondence address
                    $cor_address = UserAddress::where(['user_id'=> $user_id, 'addr_type'=> 2])->first();
                    unset($data['is_addr_same']);
                    $data['addr_type'] = 2;
                    if($cor_address){
                        $uid = array('updated_by'=> $user_id);
                        $data = array_merge($data, $uid);
                        $cor_address->update($data);
                    }else{
                        $uid = array('created_by'=> $user_id );
                        $data = array_merge($data, $uid);
                        UserAddress::create($data);
                    }
                    $data['addr_type'] = 1;
                    $this->wf_service->updateUserWfStage($user_id, 3, 12);
                }elseif($request->addr_type == 1){
                    // for permanent address
                    $per_address = UserAddress::where(['user_id'=> $user_id, 'addr_type'=> 1])->first();
                    if($per_address){
                        $uid = array('updated_by'=> $user_id );
                        $data = array_merge($data, $uid);
                        $per_address->update($data);
                    }else{
                        $uid = array('created_by'=> $user_id );
                        $data = array_merge($data, $uid);
                        UserAddress::create($data);
                    }
                    $this->wf_service->updateUserWfStage($user_id, 3, 11);
                }else{
                    // for correspondence address
                    $cor_address = UserAddress::where(['user_id'=> $user_id, 'addr_type'=> 2])->first();
                    unset($data['is_addr_same']);
                    if($cor_address){
                        $uid = array('updated_by'=> $user_id );
                        $data = array_merge($data, $uid);
                        $cor_address->update($data);
                    }else{
                        $uid = array('created_by'=> $user_id );
                        $data = array_merge($data, $uid);
                        UserAddress::create($data);
                    }
                    $this->wf_service->updateUserWfStage($user_id, 3, 12);
                }
                $request->has('is_addr_same') ? $data['is_addr_same'] = $request->is_addr_same : null;
                return Helper::sendResponse(1, 'Address detail updated successfully', 200, $data);
            }else{
                return Helper::sendResponse(0, 'Oops! You are on wrong workflow stage', 200);
            }
        }catch(\Exception $e){
            return Helper::sendResponse(0, __('common.something_went_wrong'), 500);
        }
    }

    public function updateUserBankDetail(Request $request){
        try{
            $validator = Validator::make($request->all() , [ 
                'bank_acc_no' => 'required|digits_between:9,18|numeric',
                'ifsc_code' => 'required|min:8|max:15|regex:/^[\w]*$/',
                'bank_name' => 'required|min:3|max:100|regex:/^[\pL\s\-\.]+$/u',
                'branch_name' => 'required|min:4|max:100|regex:/^[\pL\s\-\.]+$/u'
            ]);
            
            $data = [ 'bank_acc_no' => $request->bank_acc_no, 'ifsc_code' => $request->ifsc_code, 'bank_name' => $request->bank_name,'branch_name' => $request->branch_name];    
            if ($validator->fails()){
                return Helper::sendResponse(0, $validator->errors()->first() , 200);
            }
            $user_id = $request->user()->user_id;
            $wf_status = $this->wf_service->checkUserWfStage($user_id, 4);
            if($wf_status){
                $user_bank_detail = UserBankDetail::where('user_id', $user_id)->first();
                if (is_null($user_bank_detail)){
                    
                    $uid = array('user_id' => $user_id,'created_by'=> $user_id );
                    $data = array_merge($data, $uid);
                    UserBankDetail::create($data);
                }else{
                    $uid = array('updated_by'=> $user_id );
                    $data = array_merge($data, $uid);
                    $user_bank_detail->update($data);
                }
                $this->wf_service->updateUserWfStage($user_id, 4);
                $next_stage = $this->wf_service->getUserWfStage($user_id);
                return Helper::sendResponse(1, 'Bank detail updated successfully', 200, $next_stage);
            }else{
                return Helper::sendResponse(0, 'Oops! You are on wrong workflow stage', 200);
            }
        }catch(\Exception $e){
            return Helper::sendResponse(0, __('common.something_went_wrong'), 500);
        }
    }

    public function updateUserReference(Request $request){
        try{
            $validator = Validator::make($request->all() , [ 
                'ref_name_1' => 'required|min:4|max:50|regex:/^[\pL\s]+$/u', 
                'ref_mobile_1' => 'required|digits:10|regex:/[1-9]{1}\d{9}/', 
                'ref_name_2' => 'required|min:4|max:50|regex:/^[\pL\s]+$/u', 
                'ref_mobile_2' => 'required|digits:10|regex:/[1-9]{1}\d{9}/'
            ]);
            
            $data = [ 
                'ref_name_1' => $request->ref_name_1, 
                'ref_mobile_1' => $request->ref_mobile_1, 
                'ref_name_2' => $request->ref_name_2,
                'ref_mobile_2' => $request->ref_mobile_2
            ];

            if ($validator->fails()){
                return Helper::sendResponse(0, $validator->errors()->first() , 200);
            }

            $user_id = $request->user()->user_id;
            $wf_status = $this->wf_service->checkUserWfStage($user_id, 5);
            if($wf_status){
                $user_ref = UserReference::where('user_id', $user_id)->first();
                if (is_null($user_ref)){
                    $uid = array('user_id' => $user_id,'created_by'=> $user_id );
                    $data = array_merge($data, $uid);
                    UserReference::create($data);
                }else{
                    $uid = array('user_id' => $user_id,'updated_by'=> $user_id );
                    $data = array_merge($data, $uid);
                    $user_ref->update($data);
                }
                $this->wf_service->updateUserWfStage($user_id, 5);
                //$next_stage = $this->wf_service->getUserWfStage($user_id);
                return Helper::sendResponse(1, 'Reference contact updated successfully' , 200, $data);
            }else{
                return Helper::sendResponse(0, 'Oops! You are on wrong workflow stage', 200);
            }
        }catch(\Exception $e){
            return Helper::sendResponse(0, __('common.something_went_wrong'), 500);
        }
    }

    public function stageFinalSubmit(Request $request){
        try{
            $validator = Validator::make($request->all() , [ 
                'wf_stage_id' => 'required|digits_between:1,10|numeric', 
            ]);
            
            if ($validator->fails()){
                return Helper::sendResponse(0, $validator->errors()->first() , 200);
            }

            $user_id = $request->user()->user_id;
            $wf_status = $this->wf_service->isFinalWfStage($user_id, $request->wf_stage_id);
            if($wf_status){
                $this->wf_service->updateUserWfStage($user_id, $request->wf_stage_id);
                $next_stage = $this->wf_service->getUserWfStage($user_id);
                return Helper::sendResponse(1, 'Final submit done successfully' , 200, $next_stage);
            }else{
                return Helper::sendResponse(0, 'Oops! You are on wrong workflow stage', 200);
            }
        }catch(\Exception $e){
            return Helper::sendResponse(0, __('common.something_went_wrong'), 500);
        }
    }

    public function getUserWfStage(Request $request){
        try{
            $user_id = $request->user()->user_id;
            $stage = $this->wf_service->getUserWfStage($user_id);
            return Helper::sendResponse(1, 'User wf stage fetched successfully' , 200, $stage);
        }catch(\Exception $e){
            return Helper::sendResponse(0, __('common.something_went_wrong'), 500);
        }
    }

    public function getAddressDetail(Request $request){        
        try{
            $user_id = $request->user()->user_id;
            $validator = Validator::make($request->all() , [
                'addr_type' => 'required|in:0,1'
            ]);
            if ($validator->fails()){
                return Helper::sendResponse(0, $validator->errors()->first() , 200);
            }
                // for permanent address
                $per_address = UserAddress::where(['user_id'=> $user_id, 'addr_type'=>$request->addr_type])->first();
                if($per_address){
                    return Helper::sendResponse(1, 'Get Address detail successfully', 200, $data);
                }else{
                    return Helper::sendResponse(0, ' Address detail Not Found', 200, $data);
                }
        }catch(\Exception $e){
            return Helper::sendResponse(0, __('common.something_went_wrong'), 500);
        }
    }

    public function getUserKyc(Request $request){
        try{
            $user_id = $request->user()->user_id;
            $user_wf_stages = UserWfStage::with('wfStage')->where(['user_id'=> $user_id, 'parent_wf_stage_id'=>2])->get();
            $ukStages=[];

            foreach($user_wf_stages as $key=>$user_wf_stage){
                if($user_wf_stage->wfStage != null){
                    $ukStages[$user_wf_stage->wfStage->name] = $user_wf_stage->is_done;
                }
            }
            if($ukStages){
                return Helper::sendResponse(1, 'Get KYC detail successfully', 200, $ukStages);
            }else{
                return Helper::sendResponse(0, 'KYC detail Not Found', 200, $ukStages);
            }
        }catch(\Exception $e){
            return Helper::sendResponse(0, __('common.something_went_wrong'), 500);
        }
    }

}
