<?php
namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use App\Models\MstCompany;
use Helper;

class CompanyController extends Controller
{
    public function getCompanies(){
        try{
            $companies = MstCompany::where('is_active', 1)->get(['comp_id', 'name'])->toArray();
            $companies[] = ['comp_id'=>0, 'name'=> 'Others'];
            return Helper::sendResponse(1,__('common.get_all_states_success'), 200, $companies);
        }catch(\Exception $e){
            return Helper::sendResponse(0, __('common.something_went_wrong'), 500);
        }
    }

    public function createCompany(Request $request){
        try{
            $validator = Validator::make($request->all() , [
                'name' => 'required|unique:company|min:4|max:100',
            ]);
            if ($validator->fails()){
                return Helper::sendResponse(0, $validator->errors()->first() , 200);
            }

            $company = MstCompany::create(['name' => $request->name]);
            return Helper::sendResponse(1,  __('common.create_company_success'), 200, $company);
        }catch(\Exception $e){
            return Helper::sendResponse(0, __('common.something_went_wrong'), 500);
        }
    }

    public function searchCompany(Request $request){
        try{
            $validator = Validator::make($request->all() , [
                'page_no' => 'required|numeric',
                'per_page_count' => 'nullable|numeric',
            ]);
            if ($validator->fails()){
                return Helper::sendResponse(0, $validator->errors()->first() , 200);
            }

            $page_no = $request->page_no;
            $per_page_count= $request->has('per_page_count')? $request->per_page_count : 20;
            
            if($request->has('name')){
                $total_count = MstCompany::where('name', 'LIKE', '%'.str_replace(' ', '%', $request->name).'%')->where('is_active', 1)->count();
                $total_page = ceil($total_count/$per_page_count);
                $companies = MstCompany::where('name', 'LIKE', '%'.str_replace(' ', '%', $request->name).'%')->where('is_active', 1)->skip(($page_no-1)*$per_page_count)->take($per_page_count)->get(['comp_id', 'name'])->toArray();
            }else{
                $total_count = MstCompany::where('is_active', 1)->count();
                $total_page = $total_count/$per_page_count;
                $companies = MstCompany::where('is_active', 1)->get(['comp_id', 'name'])->toArray();
            }

            $companies[] = ['comp_id'=>0, 'name'=> 'Others'];
            $data =['current_page'=> $page_no, 'total_page'=> $total_page, 'total_count'=> $total_count, 'companies'=> $companies];
            return Helper::sendResponse(1,  __('common.create_company_success'), 200, $data);
        }catch(\Exception $e){
            return Helper::sendResponse(0, __('common.something_went_wrong'), 500);
        }
    }

}

