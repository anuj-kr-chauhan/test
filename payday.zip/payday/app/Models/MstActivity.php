<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MstActivity extends Model
{
    use HasFactory;

    protected $table = 'mst_activity';
    protected $primaryKey = 'id';
    public $timestamps = true;
}
