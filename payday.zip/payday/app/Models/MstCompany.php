<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MstCompany extends Model
{
    use HasFactory;

    protected $table = 'mst_comp';
    protected $primaryKey = 'comp_id';
    public $timestamps = true;
    protected $fillable = ['name'];
}
