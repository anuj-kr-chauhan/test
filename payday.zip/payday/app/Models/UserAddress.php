<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserAddress extends Model
{
    use HasFactory;

    protected $table = 'user_addr';
    protected $primaryKey = 'user_addr_id';
    public $timestamps = true;
            /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'user_id',
        'addr1',
        'addr2',
        'city',
        'state_id',
        'pincode',
        'addr_type',
        'is_addr_same',
        'is_active',
    ];

    public function state()
    {
        return $this->belongsTo(MstState::class, 'state_id', 'id');
    }

}
