<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserBankDetail extends Model
{
    use HasFactory;

    protected $table = 'user_bank_detail';
    protected $primaryKey = 'user_bank_detail_id';
    public $timestamps = true;
            /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'user_id',
        'bank_acc_no',
        'ifsc_code',
        'bank_name',
        'branch_name',
    ];

}
