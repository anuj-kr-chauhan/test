<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Program extends Model
{
    use HasFactory;

    protected $table = 'prgm';
    protected $primaryKey = 'prgm_id';
    public $timestamps = true;
    protected $fillable = ['prgm_name'];
}
