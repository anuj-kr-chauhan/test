<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProgramWfStage extends Model
{
    use HasFactory;

    protected $table = 'prgm_wf_stage';
    protected $primaryKey = 'prgm_wf_stage_id';
    public $timestamps = true;
    protected $fillable = [];
}
