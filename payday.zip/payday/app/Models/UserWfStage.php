<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserWfStage extends Model
{
    use HasFactory;

    protected $table = 'user_wf_stage';
    protected $primaryKey = 'user_wf_stage_id';
    public $timestamps = true;

    public function wfStage()
    {
        return $this->belongsTo(WfStage::class, 'wf_stage_id', 'wf_stage_id');
    }
}
