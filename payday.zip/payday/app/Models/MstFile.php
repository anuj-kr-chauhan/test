<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MstFile extends Model
{
    use HasFactory;

    protected $table = 'file';
    protected $primaryKey = 'file_id';
    public $timestamps = true;
    protected $fillable = [
        'file_type',
        'file_name',
        'file_size',
        'file_path',
        'created_at',
        'created_by',
        'updated_at',
        'updated_by',
    ];

    protected $appends = ['fileURL'];
    
    public function getFileURLAttribute(){
        return url("storage/{$this->file_path}/{$this->file_name}");
    }
}
