<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ActivityLog extends Model
{
    use HasFactory;

    protected $table = 'activity_log';
    protected $primaryKey = 'activity_log_id';
    public $timestamps = true;

    protected $fillable = [
        'activity_id',
        'activity_desc',
        'session_id',
        'ip_address',
        'route_name',
        'user_id',
        'app_id',
        'email',
        'browser_info',
        'source',
        'device_type',
        'created_at',
        'created_by',
        'updated_at',
        'updated_by',
    ];
}
