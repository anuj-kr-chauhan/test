<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserReference extends Model
{
    use HasFactory;

    protected $table = 'user_ref';
    protected $primaryKey = 'user_ref_id';
    public $timestamps = true;
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'user_id',
        'ref_name_1',
        'ref_mobile_1',
        'ref_name_2',
        'ref_mobile_2',
    ];

}
