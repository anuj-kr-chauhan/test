<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MstDoc extends Model
{
    use HasFactory;

    protected $table = 'mst_doc';
    protected $primaryKey = 'id';
    public $timestamps = true;
    protected $fillable = [];
}
