<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserKycDoc extends Model
{
    use HasFactory;

    protected $table = 'user_kyc_doc';
    protected $primaryKey = 'user_kyc_doc_id';
    public $timestamps = true;
    protected $fillable = [
        'user_id',
        'file_id',
        'mst_doc_id',
        'doc_no',
        'f_name',
        'm_name',
        'l_name',
        'is_verified',
        'verified_auto',
        'api_log_id',
        'is_active',
        'created_at',
        'created_by',
        'updated_at',
        'updated_by',
    ];
}
