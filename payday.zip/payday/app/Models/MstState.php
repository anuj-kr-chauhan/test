<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MstState extends Model
{
    use HasFactory;

    protected $table = 'mst_state';
    protected $primaryKey = 'id';
    public $timestamps = true;
    protected $fillable = ['name'];
}
