<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AppStatus extends Model
{
    use HasFactory;

    protected $table = 'app_status';
    protected $primaryKey = 'app_status_id';
    public $timestamps = true;
}
