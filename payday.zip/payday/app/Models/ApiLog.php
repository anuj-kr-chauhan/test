<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ApiLog extends Model
{
    use HasFactory;

    protected $table = 'api_log';
    protected $primaryKey = 'api_log_id';
    public $timestamps = true;

    protected $fillable = [
        'user_id',
        'doc_id',
        'doc_id_no',
        'api_name',
        'req_txt',
        'res_txt',
        'ipaddr',
        'api_url',
        'is_verified',
        'created_at',
        'created_by',
        'updated_at',
        'updated_by',
    ];
}
