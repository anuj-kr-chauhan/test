<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MstLanguage extends Model
{
    use HasFactory;

    protected $table = 'mst_lang';
    protected $primaryKey = 'id';
    public $timestamps = true;
    protected $fillable = ['lang_type','lang_name','lang_dir'];

    protected $appends = ['fileURL'];

    public function getFileURLAttribute(){
        return url("{$this->file_path}/{$this->file_name}");
    }
}
