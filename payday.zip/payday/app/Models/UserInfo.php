<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserInfo extends Model
{
    use HasFactory;

    protected $table = 'user_info';
    protected $primaryKey = 'user_info_id';
    public $timestamps = true;
            /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'user_id',
        'user_dob',
        'gender',
        'lang_option',
        'pan_no',
        'pan_f_name',
        'pan_m_name',
        'pan_l_name',
        'pincode',
        'is_married',
        'is_employed',
        'employment_type',
        'mode_of_salary',
        'monthly_salary',
    ];

}
