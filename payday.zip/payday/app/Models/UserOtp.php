<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserOtp extends Model
{
    use HasFactory;

    protected $table = 'user_otp';
    protected $primaryKey = 'user_otp_id';
    public $timestamps = true;

    protected $fillable = [
        'user_id',
        'mobile_no',
        'otp',
        'retry_count',
        'is_active',
        'valid_at',
        'created_at',
        'created_by',
        'updated_at',
        'updated_by',
    ];
}
