<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WfStage extends Model
{
    use HasFactory;

    protected $table = 'wf_stage';
    protected $primaryKey = 'wf_stage_id';
    public $timestamps = true;
}
