<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserConsent extends Model
{
    use HasFactory;

    protected $table = 'user_consent';
    protected $primaryKey = 'user_consent_id';
    public $timestamps = true;
}
