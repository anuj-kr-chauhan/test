<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MstSalaryMode extends Model
{
    use HasFactory;

    protected $table = 'mst_sal_mode';
    protected $primaryKey = 'id';
    public $timestamps = true;
    protected $fillable = ['name'];
}
