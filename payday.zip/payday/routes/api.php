<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\API\AuthController;
use App\Http\Controllers\API\UserController;
use App\Http\Controllers\API\StateController;
use App\Http\Controllers\API\SalaryController;
use App\Http\Controllers\API\CompanyController;
use App\Http\Controllers\API\LanguageController;
use App\Http\Controllers\API\ApplicationController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:api')->get('/user', function (Request $request) {
//     return $request->user();
// });

Route::group(['prefix' => 'v1', 'middleware' => 'locale'], function () {
    Route::post('/login-with-otp', [AuthController::class, 'loginWithOTP'])->name('loginWithOTP');
    Route::post('/login-with-password', [AuthController::class, 'loginWithPassword'])->name('loginWithPassword');
    Route::post('/send-otp', [AuthController::class, 'sendOTP'])->name('sendOTP');
    Route::post('/register', [AuthController::class, 'register'])->name('register');
    Route::get('/languages', [LanguageController::class, 'getLanguages'])->name('getLanguages');
    Route::post('/verify-otp', [AuthController::class, 'verifyOTP'])->name('verifyOTP');
    Route::post('/forgot-password', [AuthController::class, 'forgotPassword'])->name('forgotPassword');
    Route::post('/refresh-token', [AuthController::class, 'refreshToken'])->name('refreshToken');





    Route::group(['middleware' => 'auth:api'], function() {
	    Route::get('/logout', [AuthController::class, 'logout'])->name('logout');
        Route::get('/user', [UserController::class, 'getUser'])->name('getUser');
        Route::post('/upload-file', [UserController::class, 'uploadFile'])->name('uploadFile');
        Route::post('/upload-adhaar', [UserController::class, 'uploadAdhaar'])->name('uploadAdhaar');
        Route::post('/upload-pan', [UserController::class, 'uploadPan'])->name('uploadPan');
        Route::post('/upload-selfie', [UserController::class, 'uploadSelfie'])->name('uploadSelfie');
        Route::post('/change-password', [AuthController::class, 'changePassword'])->name('updatePassword');
	    Route::post('/stage-final-submit', [UserController::class, 'stageFinalSubmit'])->name('stageFinalSubmit');
        Route::get('/get-user-wfstage', [UserController::class, 'getUserWfStage'])->name('getUserWfStage');

        Route::post('/update-basic-detail', [UserController::class, 'updateBasicDetail'])->name('updateBasicDetail');
        Route::post('/update-employeement-detail', [UserController::class, 'updateEmployeementDetail'])->name('updateEmployeementDetail');
        Route::post('/update-address-detail', [UserController::class, 'updateAddressDetail'])->name('updateAddressDetail');
        Route::get('/address-detail', [UserController::class, 'getAddressDetail'])->name('getAddressDetail');
        Route::post('/update-bank-detail', [UserController::class, 'updateUserBankDetail'])->name('updateUserBankDetail');
        Route::post('/update-user-reference', [UserController::class, 'updateUserReference'])->name('updateUserReference');
        Route::get('/companies', [CompanyController::class, 'getCompanies'])->name('getCompanies');
        Route::post('/create-company', [CompanyController::class, 'createCompany'])->name('createCompany');
        Route::post('/search-company', [CompanyController::class, 'searchCompany'])->name('searchCompany');
        Route::post('/states', [StateController::class, 'getStates'])->name('getStates');
        Route::get('/salary-mode', [SalaryController::class, 'getSalaryMode'])->name('getSalaryMode');
        Route::get('/get-user-kyc', [UserController::class, 'getUserKyc'])->name('getUserKyc');
	});
});