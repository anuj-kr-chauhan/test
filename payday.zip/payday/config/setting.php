<?php

return [
    'prgm_id' => 1,
    'lang_array' => ['en', 'hi'],
    'comp_name' => 'PAYDAY',
    'token_expiry_time' => 10, // time in min
    'temp_token_expiry_time' => 15, // time in min
    'otp_expiry_time' => 5, // time in min
    'otp_retry_time' => 60, // time in min
    'otp_attempt' => 3,

];